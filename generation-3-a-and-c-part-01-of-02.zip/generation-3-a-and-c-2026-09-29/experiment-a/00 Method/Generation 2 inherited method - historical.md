# Travel booking experiment method and plan

Generation 2 | Working version 0.1 | 10 September 2026

Status: draft for review before implementation and experimental runs. This document records the agreed direction and proposed execution details. It does not report findings. The first-generation archive remains unchanged.

## 1. Purpose

The research asks whether a structured primer improves the reliability of AI conference-travel decisions compared with a simple task prompt, and whether a simplistic CIPDA primer can provide comparable performance to the original detailed primer with fewer instructions and lower resource use.

Decision reliability means selecting an itinerary that satisfies all mandatory requirements, or correctly recognising that no such itinerary exists. Reviewability means that the explanation accurately records the relevant facts, calculations and reasons for the decision. These outcomes will be assessed separately. A prescribed heading or refusal phrase is not evidence of a correct decision.

## 1.1 AI independence and human oversight

A secondary aim is to examine how far AI can independently assist in carrying out the experiment, including preparing materials, implementing the execution tool, capturing data, assessing outputs and producing analysis. The human operator acts as the experiment's orchestrator: setting objectives, establishing boundaries, reviewing important decisions and maintaining oversight throughout. AI independence is therefore examined within a supervised research process, not as the absence of human responsibility.

This aim is distinct from testing the booking model's decision reliability. The AI assisting with research and the model under evaluation have different roles, even if they come from the same provider. Model outputs and AI-generated assessments are not accepted as evidence of their own correctness without checks against the declared method and reference answers.

For each major stage, record what the AI completed independently, what the human instructed or approved, where human intervention was required, and what errors or corrections occurred. The chronology will summarise these events, with detailed evidence linked from the relevant run or work records. Routine approvals, substantive corrections and technical assistance will be distinguished. The resulting account will describe demonstrated independence and its limits; it will not infer autonomy merely from the successful completion of an automated task.

## 2. Relationship to the original research

The study retains the synthetic conference-travel task, controlled flight alternatives, attendance and budget constraints, and comparison of prompt conditions. It will use a reconstructed browser interface backed by Claude API execution. The researcher operates the interface and supervises runs; the software sends requests and records the returned evidence. This describes the proposed new procedure and makes no assumption about how every historical experiment was conducted.

Necessary changes address problems found in the recovered materials: inconsistent feasibility labels, reliance on keyword detection, structural scores presented as reasoning quality, incomplete raw-response preservation, reused run labels, and ambiguous treatment of technical failures. Changes to scenarios, prompts or scoring will be recorded with their reasons. This is a revised experiment, not an exact replication of the historical dataset and scoring.

## 3. Research questions

The primary question is whether decision correctness differs between the simple-prompt control, the original detailed primer, and the simplistic CIPDA primer. The principal comparison within the primer conditions is whether the simplistic primer preserves decision quality while requiring fewer instructions.

Secondary questions concern the types of errors produced, the accuracy and completeness of explanations, variation across repeated runs, output-format compliance, and input tokens, output tokens and elapsed time. The study will not assume either primer is superior. An apparently small difference will not establish equivalence without adequate precision.

## 4. Experimental conditions

| Condition | Treatment | Requirement |
|---|---|---|
| Control | A simple booking prompt with no additional reasoning framework | Receives the same task facts, mandatory rules and minimal decision-output instructions as the other conditions. |
| Original detailed primer | The original structured primer selected from the recovered research | Preserve its exact text and hash. Identify its source and distinguish it from other historical primer versions. |
| Simplistic CIPDA primer | A concise version organised around Context, Intent, Plan, Deliver and Assure | Retain the essential decision rules and assurance requirement without reproducing the detailed primer's elaboration. |

The choice of historical detailed primer must be confirmed before construction. The recovered material includes a longer XA-framed YAML primer and a shorter later three-condition runner prompt. They are not interchangeable. The simplistic primer will be drafted only after its comparator is fixed.

All three conditions will receive identical scenario facts and a common minimal output contract allowing either selected flight identifiers or an explicit no-feasible-itinerary decision. The output contract must not prescribe CIPDA stages to the control condition. Any wrapper added to the historical primer will be preserved separately and disclosed. No extra ROMER instruction will be silently added to one condition. The agreed role of ROMER in the new prompt texts will be recorded; the evidence-capture system will operate identically for all conditions.

## 5. Scenario materials

The original dataset will be preserved as source material. A working copy will undergo independent checks of dates, times, currencies, flight identifiers, prices, total costs and feasibility. Labels such as correct or trap will be withheld from model inputs.

The revised dataset must contain both feasible and infeasible cases. Otherwise a system that always refuses could appear successful. Feasible cases must include meaningful cheaper alternatives that violate attendance or budget requirements. Infeasible cases should include attendance conflicts, budget conflicts, and cases where timing and price cannot jointly be satisfied. Case types and their counts will be specified before evaluation.

The working proposal is to start with 25 validated scenarios, retaining the historical scale. The mix of feasible and infeasible cases and the final sample size remain to be approved. Repeating 25 cases does not create additional independent scenarios and will not be described as such.

Each flight will specify departure and arrival dates and a consistent time basis. For the initial study, attendance is assessed using explicitly stated arrival and departure margins. If airport transfers and check-in are excluded, the task must state that simplification. Equality at a timing boundary must have one declared rule. These choices will be settled before reference answers are calculated.

Where several itineraries meet the requirements, the reference answer will include every acceptable choice or apply the explicitly stated preference rule. Correctness will not depend on matching one arbitrary flight pair. If the task asks for the cheapest feasible itinerary, an otherwise feasible but more expensive selection will be distinguished from a hard-constraint violation.

## 6. Independent reference answers

A deterministic checker will enumerate every outbound–return combination and test the declared attendance and budget constraints. It will produce a feasibility classification, acceptable itineraries, preference-optimal itineraries, and reasons for rejecting other combinations.

The researcher will review all cases in the initial 25-case set, including the reference answers and the boundary rules. Tests will cover late arrival, early departure, over-budget totals, exact boundaries, multiple valid choices and no valid choices. The reference checker will be frozen before model evaluation and remain separate from model-generated explanations. Reference labels will not be sent to the model.

## 7. Execution and direct capture

The interface will allow the researcher to select the frozen dataset, primer versions, model configuration and run label. A local execution service will make the Claude API calls and write evidence directly to disk. API credentials will be held outside source files and logs; they will not be embedded in the HTML or exported evidence.

Each scenario-condition call will use a fresh request without prior conversation content. All conditions will use the same model identifier, generation settings, tools policy and output limit. External browsing and live booking services are outside the experiment. The model version will be selected and verified at implementation time rather than inferred from its display name.

Scenario order and condition order will be randomised using recorded schedule seeds, with condition positions balanced across repeats. The randomisation seed controls the execution schedule, not necessarily model generation. Conditions must not always run in control–detailed–simplistic order, because service load or ordering effects could affect timings.

The user requested direct desktop capture, while the new project folders are on H:. The desktop run-output location will be confirmed before execution. A recommended arrangement is a desktop results folder as the primary write location, with verified copies under 04 Runs on H:. The designated primary location, copy timing and hash verification must be explicit; the two locations must not become competing versions.

Each attempted call receives a unique identifier. Save the exact request, raw response envelope, full returned text, API usage fields, model identifier, available request identifiers, timestamps, completion or stop reason, error information and derived scores. A run manifest records hashes of the dataset, primers, checker and runner versions. Write each completed attempt immediately rather than waiting for the batch to finish. Restarting the interface must not overwrite earlier evidence.

## 8. Errors, retries and stopping

Technical errors, absent responses, truncated outputs, unreadable decision formats and substantively incorrect decisions are different outcomes. A zero-token error is not a wrong booking decision and is not a valid refusal.

A proposed policy permits up to two retries for transient technical failures, with recorded backoff. Every attempt remains in the evidence bundle. Incorrect decisions will not receive corrective feedback or regeneration during the primary experiment. A resumed run will continue only explicitly unfinished items and will preserve duplicate attempts if any occur.

The results will report performance among evaluable responses and end-to-end success across scheduled calls, together with missingness and technical failure rates by condition. Exclusions and denominator changes will be visible. The response limit will be chosen during engineering checks to avoid systematically truncating the longer condition; reaching a token limit will be evaluated using the API stop reason rather than token count alone.

## 9. Assessment

The primary outcome is first-response decision correctness against the independent reference answer. For feasible cases, this requires a permissible selection satisfying mandatory rules; for infeasible cases, it requires a correct disposition that no allowed itinerary meets the requirements. False refusal on a feasible case is an error.

Secondary measures include attendance violations, budget violations, preference satisfaction, false refusal, incorrect acceptance, explanation–decision agreement, accurate arithmetic and coverage of mandatory constraints. Formatting and keyword matches may assist extraction, but will be reported as technical indicators rather than measures of reasoning correctness.

Ambiguous responses will be reviewed using the same rule for every condition. Review will consider the full response, not only an ASSURE section. Where possible, reviewers will not see condition names, although response structure may reveal them. Reviewer decisions and reasons will be logged; disagreements will be retained and resolved by a declared procedure. No ambiguous response will be classified automatically as a reasoning failure or success solely from its format.

Reviewability will use a short rubric based on correct constraint coverage, correct calculations, consistency with the decision, and accurate explanation of infeasibility where applicable. Mandatory stage headings are not part of this quality score. The rubric and examples will be fixed before primary scoring.

## 10. Repetition and analysis

A proposed engineering pilot uses a small separate set of cases to check API access, capture, timing boundaries and parsing. It is not part of the primary results. If development uses a primary scenario, that exposure and any resulting changes must be documented.

The number of experimental repetitions will be chosen after the acceptable performance difference, expected variability and resource budget are agreed. Historical practice used repeated runs, but that alone does not justify carrying forward the same count.

Analysis will preserve pairing by scenario and repetition. Report counts, denominators, uncertainty and effect sizes for each condition, separating feasible from infeasible cases and major constraint types. Account for repeated observations of the same scenarios; do not treat all calls as independent observations. The statistical method and primary comparisons will be fixed before examining outcome differences.

To claim that the simplistic primer is no worse than the detailed primer within an acceptable tolerance, specify a non-inferiority margin on decision accuracy before the experiment and justify it practically. If two-sided equivalence is intended, define that instead. Sample size and uncertainty must support the chosen claim. If the experiment is too small, report the estimated difference and its uncertainty without claiming equivalence.

Token use will separate input from output. Timing will distinguish API-call elapsed time from total run duration, including pacing and retries. A reduction in the variability of a bounded success rate near 100% is not, by itself, evidence of a special reasoning mechanism. Explanations will be treated as model outputs for checking, not direct observations of internal computation.

## 11. Work plan and checkpoints

| Stage | Deliverable | Completion check |
|---|---|---|
| 1. Fix the method | Agreed questions, historical primer, simplistic primer, dataset mix, model settings and analysis plan | Open choices below resolved and method version frozen. |
| 2. Validate the data | Scenario set and independent reference answers | Every case reviewed; boundary and infeasibility tests pass. |
| 3. Reconstruct the tool | Browser interface, local API service and direct evidence capture | Dry runs demonstrate full capture, error handling and safe resume without paid production runs. |
| 4. Engineering pilot | Small recorded API test | Prompts, outputs, stop reasons and measurements preserved; any changes documented. |
| 5. Freeze and execute | Immutable configuration and uniquely identified runs | Execution follows the agreed schedule and budget; failures remain visible. |
| 6. Assess and reconcile | Scored decisions, reviewed ambiguities and reproducible tables | Every reported result traces to a captured response and fixed scoring rules. |
| 7. Write the paper | Method, results and limitations based on the new evidence | Claims match the measures; original and new experiments remain distinct. |

## 12. Decisions still open

1. Which recovered document is the authoritative original detailed primer?
2. What exact simplistic CIPDA text will be compared, and what ROMER instruction, if any, is part of each treatment?
3. What feasible/infeasible scenario mix and attendance-margin assumptions should be used?
4. Which Claude model, generation settings, output limit and API budget will be used?
5. Where on the desktop should primary run data be saved, and how will H: copies be verified?
6. What accuracy difference is practically acceptable for the minimalist comparison, and how many cases and repetitions can support that judgement?
7. Who will review ambiguous decisions and explanation quality?

No experimental API calls are authorised by this draft alone. This planning document does not change the archived evidence or present expected outcomes as findings.

