# Experiment A — Scope amendment 02

Recorded 2026-09-23T14:32:23.0291391+02:00, following explicit operator instruction to freeze Gemini and complete all seven reserves, confirmed by 'ok'. This amendment follows observed results and is not represented as prospective selection before all outcomes.

Gemini P07 remains frozen with one submitted B2 R01 A01 attempt yielding a generic inability message, preserved and hash verified. Nineteen scheduled slots were not submitted. Operator calls the platform failed; the evidence does not establish whether the cause was technical, refusal, or another service limitation. No reasoning-failure inference, replacement attempt, deletion, or silent exclusion is authorized by this designation.

Expand from the five-platform core roster to all seven originally registered reserves, in original register order: P05 Copilot (folder Run 5 Co Pilot desktop), P06 OxAlpha, P08 Deepseek, P09 Qwen Chat, P10 Poe, P11 Kimi, P12 Chat ZAI. These are additional platform blocks, not substitutes erasing Gemini. Preserve platform IDs and all earlier records.

Each reserve is intended to receive the same four conditions with five repetitions, fixed order, exact frozen prompts and unchanged rubric/reference. Experiment A continues to withhold policy and BIGL. Verify access, actual service/interface, model, session isolation and personalization before each block; document differences. The Copilot folder's desktop label is historical registration; actual interface must be recorded before testing and must not silently be described as desktop if browser is used.

All seven reserves remain in scope regardless of outcomes. If a platform becomes unavailable or fails, preserve the exact attempt and diagnostic evidence, mark unsubmitted slots, and continue to the next reserve under this amendment. An unexplained inability message is not automatically a reasoning error or proof of platform-wide inability. No unlogged retries or outcome-driven replacement of evidence. Existing technical-retry limits remain applicable; do not fabricate completions for blocked slots.

Raw evidence, prompt verification and hashes must be preserved before resetting each trial. Keep decisions, arithmetic, assurance, adherence and technical outcomes separate. Retain the fixed R01 second-review sample for each completed condition; unavailable sampled responses are recorded as unavailable, not replaced based on result. Lead exposure and post-result expansion limit inference. No general superiority or population-representativeness claim follows.

Off-record discussion is not incorporated as study findings. This document records only the operator-authorized change in scope and execution handling.
