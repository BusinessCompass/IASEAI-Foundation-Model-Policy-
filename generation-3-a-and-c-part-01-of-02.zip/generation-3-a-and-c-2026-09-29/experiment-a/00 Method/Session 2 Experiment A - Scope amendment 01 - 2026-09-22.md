# Session 2 Experiment A — scope amendment 01

Recorded: 2026-09-22T13:26:19.0935360+02:00
Status: agreed by the operator in conversation: 'I agree with you, lets note this change to the plan'.

The initial exploratory study scope changes from 12 platforms to five platforms in total, including the completed GPT block. The other seven registered platforms remain available for a separately documented extension. Existing recipient folders and evidence are retained.

Select and record the five-platform roster before further target-platform results are observed. The exact roster is still pending; this amendment does not select it. Use the same four intervention conditions and five repetitions per platform for the common case, with platform-specific model, settings and execution schedule recorded before each block. Experiment A continues to withhold the policy and BIGL from target runs.

Five is the initial scope, not an outcome-dependent rule to stop once five platforms agree. Retain all differences, exceptions and failed attempts. Any extension requires its rationale and scope to be recorded before the additional runs; do not claim the remaining seven would add little based on results not collected.

This amendment was agreed after inspection of the GPT block and Grok review. It is a prospective scope change for remaining work, not a preregistration before all observations. GPT has completed its 20-run block. Grok has performed reference checking and second scoring only; those reviews are not a Grok target-platform block and do not count toward five completed platforms.

Further design priority: develop additional scenarios, including infeasible cases, rather than assume that broader platform coverage on this single straightforward case is the most informative next step. No additional scenario, run count or stopping criterion is frozen by this amendment; these require a separate recorded design before execution.

The original method statement, frozen GPT protocol, schedule, prompts, reference, rubric and sealed results remain historical records unchanged. This amendment changes prospective platform scope only. Findings remain exploratory and limited to the platforms, scenarios and settings actually tested; no general reliability, superiority or equivalence claim follows from agreement on one feasible case.