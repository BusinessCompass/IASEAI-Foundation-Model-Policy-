# Generation 3 Method and Planning v0.1

14 September 2026 | Working method; not frozen for experimental execution.

## 1. Question and treatment

Experiment 1 tests no CIPDA versus CIPDA. Experiment 2 may examine how much structure is needed if evidence supports a useful benefit; Experiment 3 examines transfer across tasks, models, users and risk. A null or imprecise result is interpreted within tested conditions.

A: competent ordinary task prompting with no imposed framework. B: the same substantive information and requirements organised through Context, Intent, Plan, Deliver and Assure. The initial operationalisation is a single-request prompt intervention. It does not establish the effectiveness of a multi-turn governance cycle. API/chat mode is held fixed across A and B, not varied with treatment.

Both prompts may require ordinary care and checking. An artificially careless control would answer the wrong question. The draft pair supplies the same constraints, selection objective, explanation request and verification requirements; B adds explicit CIPDA organisation. Drafts are AI-authored after exposure to Generation 2 findings, not independent human-authored primers. Record this provenance. Verify semantic parity before freezing; retain any human revision verbatim with authorship and briefing.

ROMER is not an additional treatment in this initial comparison. Capture evidence identically outside both prompts. Any future ROMER intervention requires a method change.

## 2. Task and data

Retain the synthetic conference-travel task and reusable historical materials. Preserve original records unchanged. Create a separately versioned, validated mixed set containing feasible and infeasible scenarios; false refusals must be observable. Include cheaper invalid choices, attendance and budget conflicts, multiple valid choices and timing/budget boundaries. Do not reuse the all-refusal historical set as the sole primary test.

Every flight must have an explicit date and time on a common time basis. Initial proposed rules: outbound arrival strictly before conference start; return departure strictly after conference end; total cost less than or equal to budget. Transfers, hotels and check-in are excluded and disclosed in both prompts. Cheapest feasible pair wins; equal-cost ties are accepted. These assumptions must be written in each common task specification and independently checked.

The earlier user instruction to retain erroneous source labels is preserved: keep original labels in the archived source. Before freeze, specify precisely which conflicting annotations appear in the new cases and show them identically in both conditions. Do not silently remove this challenge, silently expose reference answers or tell the model that all cases share an answer. Prefer a separately labelled data-conflict stratum so ordinary feasibility and conflicting-metadata performance can be distinguished.

## 3. Reference answers and scoring

Enumerate every flight pair with a deterministic checker independently of tested outputs. Validate malformed inputs separately from infeasibility. Review the reference set and boundary fixtures before evaluation. Keep references in 01 Data/Reference Answers and exclude them from requests.

Primary outcome: first-response decision correctness. For feasible cases, require valid flight IDs satisfying all hard constraints; for infeasible cases, a correct no-feasible-pair decision. Report cheapest-feasible preference satisfaction separately. Hard-constraint adherence is a key reported outcome, with attendance and budget failures separated.

Secondary measures: false refusal, false acceptance, correct arithmetic, completeness of constraint coverage, explanation/decision agreement, consistency across repeats, tokens and elapsed time. Assurance quality measures accurate checking and error detection, not headings or claimed compliance. Use a common rubric fixed before scoring; assess the whole response. Hide condition identities where possible and record possible unblinding from structure. Separate evaluator models from the tested model, preserve assessments and reconcile disagreements against facts with human oversight.

Technical errors, missing responses, truncation, extraction ambiguity and wrong decisions are separate statuses. Preserve the initial attempt and retries. Report both evaluable-response correctness and end-to-end success with denominators and exclusions. Do not automatically turn UNKNOWN into a wrong decision. No correction or regeneration for a substantive wrong answer in the primary comparison.

## 4. Execution and capture

Retain the HTML oversight interface plus local API service direction. Inspect and repair inherited components before reuse; the old 200-token runner is not a validated Generation 3 implementation. Use fresh context for every scenario-condition-repeat request. Identical model, settings, tools policy, output ceiling and opportunities for both conditions. Do not include historical conclusions or expected answers in model context.

Use recorded randomisation with A/B position balanced across repeats. One attempt ID per actual call. Preserve exact request and all response blocks, full API envelope, model version, stop reason, request ID, timestamps, input/output usage, errors, retries and derived scores immediately. Freeze and hash data, prompts, common wrapper, checker, runner, settings and schedule. Never store secrets in exported evidence.

Choose an adequate equal output limit using a separate engineering pilot. Save stop reasons; do not infer truncation from length alone. Allow at most two logged retries for transient technical errors with backoff; fail the run promptly on authentication errors. Resume only unfinished scheduled items without overwriting attempts. Keep experimental data in one authoritative run location; if desktop capture is used, record and hash-verify its H: copy.

Retain the workstation operating method: human oversight, minimal assistant activity during timed model calls, no concurrent evaluator work, and log noticeable processing/network interruptions. Evening execution remains a preference, not an automation.

## 5. Analysis and inference

Use paired scenario comparisons; repetitions do not add independent scenarios. Report condition counts, effect size B minus A and uncertainty, stratified by feasibility and data conflict. Fix repetition count, sample size, practically meaningful improvement and statistical analysis before primary outcomes are examined. A proposed analysis is a confidence interval obtained by resampling whole scenarios while preserving all paired repeats; confirm suitability and precision before freeze.

Do not claim equivalence from an insignificant difference. Report uncertainty when data cannot distinguish a useful effect from little effect. Consider quality improvement alongside extra input/output tokens and time. Keep pilot, historical and primary results separate.

## 6. Working method and oversight

Carry forward Generation 2's stage sequence: fix Method; validate data and references; build and check capture; separate engineering pilot; freeze and execute; assess and reconcile; write evidence-bounded findings. Maintain the readiness register and append-only chronology. Version material changes instead of silently editing a frozen design.

Retain the secondary research aim of documenting AI independence under human orchestration. At each stage record AI work, human direction, intervention, errors and corrections. This is distinct from the tested model's decision performance.
