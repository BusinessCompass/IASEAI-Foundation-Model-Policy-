# Readiness and decisions

Started 14 September 2026. Development may proceed; this is not an executable or frozen test configuration.

| Item | Status / required completion |
|---|---|
| Research contrast | Set by user: no CIPDA versus CIPDA. |
| Generation 2 closure | Complete with explicit historical limitations; see sibling closure report. |
| Scope | Initial draft tests single-request organisation; broader governance-cycle claims excluded. |
| Prompt pair | Drafted; verify information parity and record human revisions/briefing. |
| Historical data | Copied unchanged for provenance; not validated as Generation 3 input. |
| Evaluation cases | Build feasible/infeasible set; declare case mix and conflicting-label presentation. |
| Reference checker | Validate and independently review; do not assume inherited checker is fully corrected. |
| Runner | Implement full capture, balanced scheduling, typed outcomes and safe resume; local dry-run checks required. |
| Model and resources | Exact available model, settings, pilot cap and main-run budget remain to be fixed. No experimental API calls made. |
| Statistical design | Set useful effect threshold, sample size, repeats and analysis before primary outcomes. |
| Evaluation | Freeze rubric, evaluator identity/instructions and ambiguity-resolution process. |
| Capture location | H:/04 Runs proposed authoritative location; resolve inherited desktop capture requirement before pilot. |
| Pilot and freeze | Separate engineering cases, capture validation and versioned freeze required before primary testing. |

Next work: construct the matched mixed-feasibility dataset and independent references, audit the draft prompt pair, then repair capture and execution. Do not resume the closed Generation 2 run plan.
