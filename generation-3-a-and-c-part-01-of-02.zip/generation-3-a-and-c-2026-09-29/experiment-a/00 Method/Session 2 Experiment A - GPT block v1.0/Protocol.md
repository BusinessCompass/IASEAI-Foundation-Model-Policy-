# Experiment A - first GPT block v1.0

Status: protocol and schedule frozen for a prospective exploratory block; no block runs started. This freeze follows inspection of engineering outputs and is not a preregistration made before all observations.

## Scope

One reviewed synthetic case, four conditions, five repetitions: 20 scheduled runs on ChatGPT. Target visible selection GPT-5.6 Sol, Medium; fresh Unpersonalized temporary chat for every attempt. Exact backend version may be unavailable. Verify visible model at start and after any interruption or apparent change; retain the actual label, never infer it. Block ID P01, case T01 aliases the unchanged G3S2-ENG-T01 source task. Source bytes are identical to the pilot pack. Engineering runs, infrastructure checks, extra B4 deviation and Grok reference review are excluded from this block.

This is the first within-platform block, not the entire 12-recipient study. No other recipient's count or model is frozen here. The chosen five repetitions follow the method's initial proposal. One feasible case cannot measure false acceptance on infeasible tasks, performance across consequences, or general task reliability. Do not claim governance superiority, equivalence, proportionality across task types or independent samples of tasks from these 20 responses.

## Frozen target exposure

Submit only the corresponding - SUBMIT.txt content. No policy, BIGL table, schedule, expected answer, previous output, condition label or research hypothesis goes to the target. B1 is ad hoc and permits spontaneous structure. B3/B4 governance records are prescribed interventions; optional scorecards in the revised policy do not remove these experimental requirements. All common task facts, tools restriction and action boundaries are identical.

## Execution

Follow schedule.json exactly, one attempt at a time. Use the evidence_guard procedure with exclusive IDs, expected source-byte hash, composer comparison, a one-send intent recorded before clicking Send, and post-submission visible-text verification. Do not use shared mutable browser helper bindings or clipboard evidence. Confirm a visibly empty and unpersonalized chat; a reload alone is not proof. No manual changes to prompts.

Capture full submitted message, full response, visible expanded work summaries, DOM and screenshot. Verify completion controls and absence of a stop-generation control. Save real screenshot type correctly; preserve original bytes. If a PNG rendition is needed, label it as derived. Hash and copy evidence to 01 Data/Run 1 GPT/<attempt_id> before resetting. Keep reference/scoring files elsewhere. During output, retain occasional timestamped observations when needed to assess visible chronology; do not call them a complete streaming or internal-reasoning trace.

No corrective prompting or regeneration for poor answers. Clarification requests are retained as incomplete; do not supply improvised facts. A technical failure or request mismatch remains an attempt in the denominator and is excluded from substantive condition scoring. Allow at most one technical replacement with a new A02 ID, after resolving the cause, directly after the failed slot. A failed replacement stops the block for investigation. Uncertain submission state must be inspected before retry; never blindly resend. Any model/settings/source change stops the block pending a documented amendment.

## Assessment and analysis

Use the frozen rubric. Codex supplies first-pass assessments, explicitly identified as unblinded lead assessment, separate from target self-review. A second reviewer should review at least one preselected response per condition (repetition 1), with disagreements retained. If no independent reviewer is available, mark the second review pending rather than claiming it complete. Grok's reference check corroborates this task's answer; memory/custom-instruction isolation was unverified and a minor boundary-description error was retained. It is not independent scoring of block responses.

Report condition counts out of five scheduled slots, all attempted submissions including replacements, evaluable counts and failures. Report first-attempt success separately from recovered success. No composite score. Compare observed adherence, evidence coverage, correct selection, errors and output length descriptively. Input/output word counts are whitespace counts, not tokens. Label elapsed time as observed submission-to-completion time; polling/inspection overhead remains. Record NA for unavailable measures. Do not issue significance or equivalence claims from this small single-case block.

## Change control

Every source, rubric and schedule is SHA-256 indexed in freeze-manifest.json. Changes require a new version and explicit reason before affected execution; keep completed evidence under its original version. This document freezes preparation; the operator's next execution instruction can start the block.
