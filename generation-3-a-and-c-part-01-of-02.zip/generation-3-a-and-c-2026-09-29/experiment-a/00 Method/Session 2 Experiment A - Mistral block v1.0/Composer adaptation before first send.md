
## 2026-09-22T14:31:34.3411003+02:00 — Mistral composer preflight adaptation, before first send
Mistral fill converted the full prompt to a Pasted text card; initial visible-composer comparison rejected the card summary. No send occurred. Clicking the card expanded all text inline, which matched the frozen source after whitespace normalization. Execution will expand any such card and verify full inline content before arming Send. No prompt edit or experimental replacement; this is a pre-send UI adaptation.

