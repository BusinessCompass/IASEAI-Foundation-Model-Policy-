# Experiment A — Grok target block v1.0

Prospective execution freeze for P02, case T01: four conditions, five repetitions, 20 scheduled slots. The common task and four exact prompts remain those frozen for GPT. Use the same scheduled condition order for matched replication. This follows GPT result inspection and Grok reference/second-review exposure; it is not preregistration before all observations.

Target: Grok web, Fast mode. Exact backend model is not exposed; do not invent it. Fresh visibly empty Private chat for each attempt. Preflight observed empty custom-instruction field and history personalization OFF. Preserve that dated evidence; it does not retrospectively establish earlier reviewer isolation. No policy, BIGL, reference, rubric, schedule, condition labels, prior responses or scores are submitted. Only exact frozen corresponding SUBMIT prompt goes to the target. Reviews remain outside this block.

Verify visible Fast mode and empty private chat before every submission. Keep prompt hashes, observed composer, exclusive send-intent and exact request bytes. Grok renders Markdown list prefixes: post-submission comparison may remove only line-leading list markers and normalize whitespace, retaining both raw source and rendered article. Any other difference is a technical mismatch; preserve and investigate. This is an explicit platform capture adaptation, not a prompt change.

Capture submitted article, full response, conversation text, DOM, screenshot and completion metadata. Expand visible work summaries when present; do not request hidden reasoning. Completion requires Copy response and no Stop model response. Screenshot is viewport corroboration; text and DOM are the complete primary record. Seal and hash-verify each H: copy before resetting. No clipboard capture or mutable current-condition variables.

Use explicit IDs/index checks. No corrective prompts/regenerations for poor answers. Retain technical failures separately; allow at most one A02 replacement after resolving the cause, then stop if replacement fails. Stop on settings/model/source change or uncertain submission. Never overwrite evidence or retry an uncertain send blindly.

Apply the unchanged frozen GPT rubric and reference. Lead first pass is unblinded. Preselect R01 of each condition for a separate second assessor; Grok must not act as its own independent reviewer. Retain disagreements. Report five scheduled/evaluable counts per condition, first-attempt and recovered outcomes, word counts and observed timings with overhead. No composite or significance/equivalence claims. One feasible case cannot establish general reliability or infeasible-case performance.

Platform roster: GPT, Grok, Mistral (existing Run 3 Vibe folder), Lumo, Gemini. Other seven platforms are reserved. Mistral folder mapping will be checked at its preflight; do not rename historic folders. Original GPT records remain unchanged.
