
## 2026-09-23T09:23:17.4963525+02:00 — Lumo pre-send composer adaptation
Full fill converted prompt to pasted-text file card; no send occurred. Preview inspected, then unsent draft cleared by reload. Ghost mode re-enabled. Long sequential typing timed out after 70 characters; partial draft cleared. Short 400-character type insertions retained inline text, and full textarea value matched frozen source exactly (2920 characters). Adopt short inline insertions with exact full-value check before send; no prompt amendment or technical replacement. Reload resets Ghost mode and must be followed by explicit enable/verification before every run.

