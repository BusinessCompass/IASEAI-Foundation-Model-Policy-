# Generation 3 Session 2 Experiment A — Scope amendment 03

Recorded 23 September 2026, before any DeepSeek target submission.

Operator instruction: "after Deepseek we stop as I don't think further work is adding value". DeepSeek (P08) is the final intended platform. This supersedes amendment 02's requirement to test every remaining reserve. P09 Qwen Chat, P10 Poe, P11 Kimi and P12 Chat ZAI will not be started under the current scope. No outcome-dependent exception to this stop has been authorized; the earlier assistant's "unless" qualification is not the operator's instruction.

This is a post-result scope reduction following completed core/Copilot blocks and the preserved Gemini and OxAlpha interruptions. Record the operator's resource/value judgment; do not portray the reduction as prospectively specified statistical saturation or proof that additional platforms would add no information. Preserve all earlier attempts and failures. DeepSeek retains the unchanged twenty-slot matched design, frozen prompts, rubric and evidence safeguards, subject to the existing technical-failure handling rule. Experiment A continues to withhold policy and BIGL.

Completing outstanding evidence preservation and assessment of collected responses remains distinct from collecting additional platform trials. OxAlpha has one substantive response awaiting assessment, one technical provider error and eighteen unsubmitted slots. No DeepSeek prompt was sent during the Codex usage-limit interruption; that interruption is an executor resource event, not a DeepSeek failure.

On resumption, DeepSeek opened signed in to an empty chat. Data settings show "Help improve the model for everyone" enabled. No setting changed and no trial submitted at this preflight checkpoint.
