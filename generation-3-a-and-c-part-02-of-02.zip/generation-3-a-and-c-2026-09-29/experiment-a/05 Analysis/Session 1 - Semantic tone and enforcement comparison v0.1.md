# Session 1 — Semantic tone and enforcement comparison v0.1

16 September 2026. Follow-up to the comparative primer assessment. Human question: ascertain semantic differences in tone or enforcement.

## Conclusion and scope

Yes: several pairs change what the receiving agent is instructed to do, not merely how the text looks. The direction is mixed. Some CIPDA versions add checks, correction duties or explicit authorisation; others introduce ambiguity or only surround the same primer with authoring commentary. No downstream behaviour has been tested, so enforcement here means instruction strength and decision gates, not demonstrated compliance or software enforcement.

Assessment uses the saved text, not assumed model intent. U = unstructured; C = CIPDA-labelled file. Quotations below are from those files in 02 Primers. Underlying model identities, exact requests and session histories remain unverified. A difference within a pair is not by itself a causal effect of CIPDA.

## Coding distinctions

- Obligation: may/try/should versus must/only/do not; interpret the whole passage, not isolated words.
- Authority: who may commit, approve, change or stop the booking.
- Gate: a condition that must be satisfied before action, including corrective action when it fails.
- Scope: whether the agent books, proposes, coordinates or writes instructions.
- Epistemic stance: uncertainty disclosure versus unsupported assertions that checks succeeded.
- Rhetorical tone: emotional force, politeness or evaluative language. Strong rhetoric does not necessarily change the allowed action set.

## Paired findings

| Pair | Evidence and semantic difference | Interpretation |
|---|---|---|
| GPT | U says “take the seller’s reputation into account”; C says “Use reputable purchasing channels.” U says permission “should be requested” where appropriate; C Plan says “obtain clarification or permission” for material departures. C also introduces “where authorised” booking and a before-finalisation verification section. | Moves seller consideration toward a directive and makes authorisation/checking more explicit. Clarification OR permission is not an unconditional approval requirement. C's isolated “Prefer options” wording does not make attendance optional because surrounding text explicitly rejects attendance-defeating options. |
| Grok | U already says “Check that the final result matches” timing/routing constraints. C expands the checks to coordination, stopping and absent-source constraints, and says “If any check fails, correct the result or state the residual uncertainty.” | Broader assurance, but not a universal hard stop: reporting uncertainty is an alternative to correcting failure. Both allow hotel adjustment with notification rather than clearly requiring prior approval. C's “keep the date ranges identical” is more literal than U's synchronization wording and may create a stricter, potentially problematic interpretation. |
| Vibe | U already says the agent “must” seek permission before finalizing changes. C repeats confirmation requirements, but Assure states “None identified” for evidence omissions and errors; the ROMER report says the booking aligns with the schedule. | Little new authority restriction. The larger change is from prospective instruction to self-certifying language, despite no actual itinerary being established. This can sound more certain without providing a stronger operational gate. U's “departs immediately” is not consistently carried into C, which mainly says “after.” |
| Lumo | U says “Verify the reliability of the seller”; C says “Complete a purchase only with a reliable seller” and “If any check fails, correct it before delivering.” Both already require approval before changes and prefer no booking to a wrong booking. | C makes the purchase and correction gates more explicit, rather than inventing the underlying safety priority. Tone remains forceful. “Just in time is acceptable” versus later “arrival before” leaves the equality boundary ambiguous. Exact duplicated C body increases emphasis/exposure, not the distinct rule set. |
| Copilot | U says “Finally, if no valid flight exists, you must stop and ask the user for guidance.” The C Deliver primer says “stop and report that the booking cannot be completed.” Its outer Assure states “No new requirements were added.” | The explicit duty to seek guidance is reduced to reporting failure in the embedded primer. Outer self-assurance is about authorship, not a booking-time safeguard. This pair cannot be treated as merely the same booking policy under five headings. |
| OxAlpha | U already requires approval “before booking anything.” C repeats “wait for approval” and asks “Did I get explicit approval before payment?” C says discard suspiciously cheap offers “unless verified” and distinguish verified facts from inference. | Approval is retained and made more auditable, not newly introduced. Seller screening and evidence/uncertainty duties become more explicit. Tone shifts from a personal request toward a procedural checklist while retaining first-person authority. |
| Gemini | U requires morning arrival on opening day and departure just after the last session. C retains those boundaries and adds “Confirm joint logical consistency across both legs before completing the booking.” | Core timing strictness is already present in U. C adds an explicit combined check; its more formal phrasing is not evidence that timing has become substantively stricter. Neither version specifies what happens if the check fails. |
| Deepseek | U asks the agent to “take care of booking my travel,” with permission before changes. C Intent says the output is a plan for review before booking; Outside scope says “not ... actually complete the booking transaction.” Deliver then repeats the booking-oriented prose. | A material shift toward proposal-only authority appears in the outer C text, but conflicts with the embedded primer. This is an unresolved scope conflict, not a clean strengthening of enforcement. Tone remains personal and protective; outer assurance adds certainty about the artifact. |
| Qwen | U already says coordinate to book colleagues on the same flight with adjacent seats. C asks “are they on the same flight with adjacent seats?” and says “If any of these checks fail, revise your selection before completing the task.” | C makes an existing coordination objective a checked completion condition. It adds a correction duty without a clear infeasibility/waiver route. That could change how unavailable adjacent seats are handled; actual refusal behaviour is untested. |
| ZAI | The 498-word receiving-agent instruction body in U is reproduced exactly in C Deliver. Outer C/ROMER adds “No unsupported additions detected” and “Errors: None material.” | No wording-based tone or enforcement difference within the identical instruction body. The full response adds evaluative authority and self-certification; its effect depends on whether the wrapper is supplied to the receiving agent. Do not attribute wrapper properties to the unchanged body. |
| Poe | U contains a detailed booking workflow and commitment checks; C is a generic CIPDA outline without the conference task. | Missing task-specific comparison artifact. The apparent loss of booking rules cannot fairly be interpreted as a paired change in enforcement. |
| Kimi | Only U is present. | No paired inference possible. |

## Across-service tone and enforcement differences

Independent of condition, the drafts implement different policies. Grok permits hotel changes with notification; GPT uses context-dependent clarification/permission; OxAlpha demands approval before booking; Deepseek C includes proposal-only authority. These are materially different delegations of power.

Seller language also ranges from considering reputation (GPT U), through verification (Lumo U), to refusing suspiciously cheap sellers (Deepseek). Caution, mandatory investigation and outright exclusion are not semantically equivalent.

Lumo and ZAI use stronger negative evaluation and loss framing: wrong actions are worse than inaction, cheap invalid tickets are wrong answers. GPT and Grok generally state rules more neutrally. OxAlpha and Deepseek express priorities as a traveller's personal preferences. These rhetorical choices may make the same constraint more salient, but they do not establish greater compliance.

Assurance often changes genre: an instruction to check becomes an assertion that checks passed. Vibe, Copilot, Deepseek and ZAI contain authorial assurance claims. Record these separately from executable criteria, correction requirements and evidence of actual checks.

## Implication for the experiment

The saved conditions are not consistently equivalent policies with different presentation. They vary in authorisation, correction duties, constraint rigidity, output scope and certainty. Any later difference in booking performance could reflect these changes as well as CIPDA organisation.

Retain these original drafts for Session 1's naturalistic authoring comparison. If a later study aims to isolate framing alone, create separately versioned matched instructions that preserve each rule's scope, obligation and exception, and decide whether the receiving AI gets the primer alone or the whole authoring response. Do not edit the original artifacts to manufacture parity.

These are evidence-based textual interpretations, with clear cases (exact reuse, explicit proposal-only wording, added correction duties) distinguished from contextual readings (modal force and timing boundaries). They are not statistical sentiment scores, source-fidelity verification, or measured behavioural outcomes.
