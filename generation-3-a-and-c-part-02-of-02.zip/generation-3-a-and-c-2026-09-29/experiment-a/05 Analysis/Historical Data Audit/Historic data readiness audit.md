# Historic data readiness audit

16 September 2026. Human instruction: check historic data; executions are one task at a time; prepare scoring now but keep it entirely separate for Session 3. No experimental response has been scored.

## Source and checks

Read Original/historical_scenarios_125.json without modifying it. Parsed all 125 scenarios and all 500 flight options; enumerated 500 outbound/return pairs. The source hash, detailed conditional references and checker are in the restricted-by-workflow Session 3 scoring folder. Five checker boundary assertions passed. A separately expressed PowerShell clock-time check also found 125 starts at 09:00, no case with an outbound before start, and 125 true labels on 09:15 arrivals. This is a cross-check by the same assistant, not independent human validation.

## Findings

- 125 unique scenario IDs, matching the declared scenario count.
- Every conference starts at 09:00 and ends at 17:00.
- Every case's earliest outbound arrival is 09:15; all other outbound arrivals are later.
- Under the explicit interpretation that outbound flights occur on the conference opening date and all clocks share a time basis, all 125 cases are infeasible. The result is unchanged if equality at 09:00 is permitted, because every arrival is later.
- 125 meetsConstraint labels contradict that timing interpretation. The apparent valid outbound is labelled true despite its 09:15 arrival after the 09:00 start.
- 19 correctBooking records lack flight IDs. All 106 resolvable correctBooking records select an infeasible pair under the audit interpretation.
- 18 trapBooking records lack flight IDs. No cost mismatch was detected among records whose flight IDs could be resolved; incomplete IDs prevent equivalent checking of every record.
- All 500 flight entries lack explicit flight dates. Their fields also contain no time zones or date offsets. Therefore elapsed durations and full chronological feasibility cannot be established from the raw clocks alone.
- 59 flight entries show arrival clock time earlier than departure clock time. This is a diagnostic ambiguity, not proof of impossible travel: dates and zones are absent.
- correctBooking, trapBooking, meetsConstraint, isTrap and narrative notes expose answer-like annotations. They are historical claims, not trustworthy reference answers.
- No itinerary waypoints, flight-specific seller evidence, seating inventory or hotel availability is provided. Routing, reputation, adjacent-seat feasibility and hotel-change success cannot be scored objectively from these data. Currency and budget support cost checks, but do not fill those gaps.

## Readiness decision

The historical file is not a validated general Generation 3 benchmark. It may be useful as a separately declared conflicting-data/ambiguity challenge. On the audit interpretation it provides no feasible cases, so an always-refuse policy could appear successful. Without explicit date/time assumptions, recognising missing information is defensible; unconditional infeasibility must not be treated as established ground truth.

Preserve every original label unchanged. No execution derivative has been created, and no annotations have been silently removed or repaired. Before use, fix the common date/time basis and decide which answer-like annotations are visible identically in both conditions. Retaining erroneous labels as a deliberate challenge is distinct from exposing the evaluator's independently derived reference answers. If a facts-only variant is desired, create a separately versioned derivative with an explicit transformation record.

A broader performance test needs a separately versioned mixture of feasible and infeasible cases. Additional evidence is required to test routing, sellers, seats or hotel dependencies. Do not present these historical cases as testing the whole content of the primers.

## Separation and next session

Session 3 scoring materials are prepared separately under 05 Analysis/Session 3 Scoring - DO NOT SUBMIT. They contain the rubric, machine-readable blank assessment template, audit checker, source hash and conditional per-case references. This folder is not part of a tested-AI upload package. The reference answers are conditional and the rubric is draft pending execution assumptions; neither is declared frozen.

Run one task at a time, save its exact input/output and intervention record, then close that execution before starting another. Do not score responses in this execution session. The later scorer receives archived evidence in a separate context. This is procedural separation; no operating-system access controls have been added.
