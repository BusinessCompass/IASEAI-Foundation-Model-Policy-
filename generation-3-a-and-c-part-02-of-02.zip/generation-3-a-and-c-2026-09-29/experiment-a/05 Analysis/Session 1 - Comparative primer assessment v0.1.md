# Generation 3, Session 1 — Comparative primer assessment v0.1

Date: 16 September 2026. Status: initial descriptive assessment by Codex; not independently rated or a test of booking performance.

## Objective

Human clarification: compare the drafting prompts and resulting primers for hidden structure in the unstructured condition, sentiment, style, verbosity, and other relevant differences. This is an assessment of instruction artifacts. It is not yet an experiment measuring their downstream booking effectiveness.

## Material and method

Read all 23 condition text files across 12 service-labelled runs, the unstructured construction prompt, and the CIPDA/ROMER outline. Eleven runs have both condition files; Kimi has only the unstructured condition. Service names do not establish underlying model identity. The source register records file hashes and provenance limitations.

Qualitative judgments below are manual, descriptive and evidence-linked by filename and brief excerpts. They are not sentiment-model scores. Word counts use non-whitespace spans (regex \S+) over the complete saved file, including headings, notes, traces and duplication; punctuation-only spans may count. These are reproducible length measures, not tokenizer counts or measures of useful information. Missing files are missing, not zero-length answers.

The Dignum paper was not independently checked in this assessment. Statements about additions refer to differences between artifacts or specificity requiring source verification, not established errors relative to the paper. Exact submitted CIPDA requests and full interaction histories remain unavailable here. Consequently, an apparent condition mismatch cannot automatically be attributed to a model ignoring its actual instructions.

## Drafting prompt comparison

The unstructured construction prompt already supplies considerable task structure: identify source scenario, synthesize a self-contained primer, preserve constraints, exclude unsupported requirements, avoid solving the task, and append an ambiguity note. It prohibits named frameworks and requests natural, unstructured writing. Thus it is a constrained drafting task, not an absence-of-structure baseline. Its output-plus-note requirement itself introduces two output components.

The CIPDA/ROMER outline supplies a broader process: establish context and intent, plan, deliver, assure, and provide a reviewable trace where requested. It explicitly says functional sufficiency matters more than rigid formatting. It can therefore reasonably be applied to primer authorship rather than inserted into the receiving booking agent's instructions. Copilot, Deepseek and ZAI exhibit this authorship interpretation; ZAI explicitly explains the choice. Vibe, OxAlpha and ZAI include ROMER material. The outline alone does not establish that identical requests were sent to every service or that a trace was required in each case.

For analysis, distinguish three objects: the request to the authoring AI, the full authoring response, and the actual primer intended for the receiving AI. Comparing different objects would confound structure, verbosity and style.

## Structure and sentiment criteria

Visible structure means headings, labelled fields, lists or staged layouts. Latent structure means ordering, conditional branches, priorities, stop rules, dependencies and verification requirements expressed in ordinary prose. Neither necessarily means CIPDA specifically. A coherent ordinary instruction will usually contain some latent structure; that alone is not evidence of experimental contamination or deliberate concealment.

Sentiment is separated into affective/rhetorical tone, strength of obligation, confidence, and risk framing. Negative words about bad bookings are task warnings, not evidence that a model has a negative attitude. Politeness is not weak constraint enforcement. Claimed assurance is not demonstrated assurance.

## Run-by-run assessment

| Run | Unstructured form and latent structure | Tone/style | CIPDA form and material comparison issue |
|---|---|---|---|
| GPT | Topic-based prose with timing priority, routing limits, coordination dependencies, seller caution and missing-information handling. Low overt formatting, substantial latent rules. | Professional, measured; conditional language such as permission “where appropriate.” | Booking-task CIPDA with explicit search sequence and final checks. Much longer; makes process and scope exclusions more explicit. Length increase is not pure reformatting. |
| Grok | Compact continuous instructions: task → timing/routing → coordination → stopping → final check. “Check that the final result matches” is explicit assurance without a framework label. | Direct, neutral and procedural. | Booking-task CIPDA with enumerated workflow and assurance checklist. Both versions omit seller discussion found in several other services. Hotel adjustment plus informing the user differs from stronger approval gates elsewhere. |
| Vibe | Clearly visible sections: “Task,” “Scenario,” “Constraints and Considerations,” “Unclear Aspects.” Not merely hidden structure. | Formal template style, repeated obligations and declarative confidence. | Booking CIPDA plus ROMER. Assurance says “None identified” for overlooked evidence/errors; trace includes success-like statements about a booking despite no booking being performed. These statements should not count as verified success. |
| Lumo | Paragraph lead-ins act as headings: “The task,” “Know when to stop,” “Shop carefully.” Strong priorities, branches and escalation rules. | Emphatic and cautionary: “absurd detour,” “wrong booking is worse.” | Booking CIPDA, with the entire Context-to-interpretation-note body duplicated exactly in the saved file. Raw verbosity is inflated by capture/content duplication of unknown origin. Also mixes “just in time is acceptable” with “arrival before,” leaving a boundary ambiguity. |
| Copilot | Mostly prose, but organized by rule topics, repeated source quotations, and an ambiguity list. | Authoritative, quotation-heavy, repeated “must”; confident claims of direct support. | CIPDA governs primer construction. Deliver contains prose primer; Plan explicitly says keep CIPDA outside it. Its own description calls the primer unstructured. Full-file comparison would mix author commentary with deployment instructions. |
| OxAlpha | First-person requester prose, with sequential search, screening, approval and failure branches. | Conversational yet directive; approval-centred and risk-averse. | Booking CIPDA plus ROMER. Direct-only-first preference and explicit approval appear in both. Source note filename indicates a text dump instead of PDF. CIPDA text has missing words (“on the of the last day”; “direct flights for the required dates”) and trailing “Copy”; preserve and flag rather than silently repair. |
| Gemini | Flattened text still contains labels: “Task & Operational Constraints,” “Goal,” “Timing & Schedule Alignment.” Visible conceptual sections survive lost line breaks. | Compressed, technical, categorical: “strictly,” “all.” | Booking CIPDA, also flattened. Both impose morning arrival on the opening day and return just after the final session. This is a narrower timing interpretation than general full-attendance coverage; source verification is needed. |
| Deepseek | Topic-organized first-person prose: purpose, route, timing, hotel, seller, escalation, long interpretation note. | Personal preference framing (“I would rather”), protective and cautionary. | Mixes booking context with primer-authoring Plan/Assure, then substantially repeats the earlier prose in Deliver. Outer text says proposal only while inner text asks for booking travel. Both contain detailed hotel-night rules that need separate source-fidelity review. |
| Qwen | One main paragraph plus interpretation note; sequence and stopping rule are explicit despite minimal layout. | Concise, direct and procedural. | Booking CIPDA adds step sequence, flight/seat output fields and corrective checks. Adjacent seats are treated more like an achieved requirement than a best-effort goal. Same-flight/adjacent-seat feasibility deserves explicit treatment. |
| Poe | Extensive visible headings, execution flow, constraints, checking gates and output specification. Strongest overt structure among nominal unstructured files. | Didactic and repetitive; “critical,” “must,” “always” convey urgency. | Saved CIPDA file is a generic framework outline with no conference-specific primer. It is not a comparable completed booking primer on the evidence available. Its shorter length is not evidence of better concision. |
| Kimi | Brief paragraph plus note; timing, routing, bounded search and abstention rules supply latent structure. | Compact and neutral with cautious failure handling. | No CIPDA file. Account/access note filenames explain an apparent interruption, not a paired quality result. Exclude from paired differences. |
| ZAI | Flowing thematic prose with priority rules, explicit numerical checks, conditionals, dependencies and stop/ask gate. | Most overtly rhetorical: “it isn't a bargain, it's a wrong answer”; “A seller's reputation is part of the real price.” | Explicitly applies CIPDA/ROMER to authorship. The full 498-word unstructured instruction body is present exactly in Deliver. Much of the length increase is wrapper, interpretation and self-assessment, not a different receiving-agent instruction. |

## Main findings

1. “Unstructured” is not a uniform condition. Vibe, Lumo, Gemini and especially Poe visibly organize the text; GPT, Grok, OxAlpha, Deepseek, Qwen, Kimi and ZAI largely use prose with substantial latent rules. An ambiguity note or title alone should not be penalized as framework use because the construction prompt requests a note.
2. CIPDA is implemented at different levels: receiving-agent workflow, authoring process, a hybrid, or generic outline. This is the largest comparability problem. It is more consequential than whether the five headings appear.
3. Tone differs materially across services. GPT/Grok/Qwen/Kimi are relatively restrained; Lumo/ZAI use stronger evaluative rhetoric; OxAlpha/Deepseek use first-person preferences and approval framing; Copilot leans on quotations and authority. These are textual observations, not model personality claims.
4. Longer outputs often repeat constraints across Context, Intent, Plan and Assure, or reproduce the earlier primer. Repetition may emphasize rules, but its benefit has not been tested. Lumo's exact duplication must be isolated from substantive elaboration.
5. Content and authority also vary: seller checks, hotel scope, direct-flight priority, seat adjacency, booking versus proposal, mandatory user approval, and strict timing. These are potential influences on later outcomes independently of CIPDA organization.
6. Some assurance sections report their own correctness without an independent check. Code these as assurance assertions, distinct from actionable checks or evidence that a check succeeded.

## Recommended continuation within Session 1

Keep originals immutable. Annotate each file into instruction body, interpretation note, authoring wrapper, ROMER trace and capture artifact, retaining exact source offsets. Report full-file and instruction-body lengths separately; do not silently remove duplication. Establish which text would actually be passed to the booking AI.

For each pair, map shared rules and additions/deletions, distinguishing reformulation from changed obligation (e.g. may/should/must), changed authority, new action, or narrowed timing. Verify contentious requirements against the paper in a separate source-fidelity pass. Recover exact submitted requests and ordering before judging compliance or independence; references to a previous response show context dependence in some files but do not establish all session histories.

Use a common descriptive coding guide for visible structure, latent structure, formality, rhetorical intensity, uncertainty, repetition, scope and actionable assurance. If quantitative ratings are needed, define anchors before scoring and have a second independent reviewer assess a subset or all files. This first pass is exploratory, not preregistered or independently validated. Do not infer CIPDA effectiveness from style or length alone.

## Complete-file word counts

| Run | Unstructured | CIPDA | CIPDA / unstructured |
|---|---:|---:|---:|
| Run 1 GPT | 377 | 859 | 2.28 |
| Run 2 Grok | 234 | 558 | 2.38 |
| Run 3 Vibe | 361 | 952 | 2.64 |
| Run 4 Lumo | 792 | 2119 | 2.68 |
| Run 5 Co Pilot desktop | 694 | 913 | 1.32 |
| Run 6 OxAlpha | 466 | 967 | 2.08 |
| Run 7 Gemini | 248 | 409 | 1.65 |
| Run 8 Deepseek | 757 | 2154 | 2.85 |
| Run 9 Qwen Chat | 265 | 521 | 1.97 |
| Run 10 Poe | 1114 | 247 | 0.22 |
| Run 11 Kimi | 176 | Missing | Missing |
| Run 12 Chat ZAI | 725 | 1798 | 2.48 |

Lumo: the duplicated body has 1,054 words per copy; the complete saved file has 2,119 spans including its repeated title. Removing one exact body copy would leave 1,065 spans, about 1.34 times the unstructured file, rather than the raw 2.68 ratio. This is a sensitivity calculation, not an edit to evidence.
ZAI: the instruction body alone has 498 words and is exactly contained in the CIPDA file; full files have 725 and 1,798 words.
Poe and Kimi are not eligible for an ordinary completed-primer paired length interpretation. Among the other ten complete-file pairs, each CIPDA file is longer; magnitude combines substantive elaboration, repetition, authoring commentary and capture effects.
