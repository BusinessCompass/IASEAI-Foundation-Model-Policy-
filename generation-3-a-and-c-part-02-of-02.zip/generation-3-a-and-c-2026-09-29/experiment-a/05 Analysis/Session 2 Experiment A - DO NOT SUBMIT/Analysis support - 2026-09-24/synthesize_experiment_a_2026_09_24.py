from pathlib import Path
from datetime import datetime
from collections import Counter
import json,hashlib

root=Path('H:/Travel Booking Experiment Generation 3')
base=root/'05 Analysis/Session 2 Experiment A - DO NOT SUBMIT'
out=base/'Cross-platform synthesis v1.0 - 2026-09-24'
at=datetime.now().astimezone().isoformat()
dims=['constraint_explanation','arithmetic','evidence_linkage','reconstruction','uncertainty','assurance']
platforms=['GPT','Grok','Mistral','Lumo','Copilot','DeepSeek']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sources={};verified=0;allrows=[]
for platform in platforms:
    folder=base/(platform+' block v1.0')/'Lead assessment v1.0'
    manifest=json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
    for n,h in manifest['files'].items():
        assert sha(folder/n)==h,(platform,n)
        verified+=1
    p=folder/'assessments.json';sources[str(p)]=sha(p)
    data=json.loads(p.read_text(encoding='utf-8'))['runs']
    assert len(data)==20
    assert Counter(r['condition'] for r in data)==dict.fromkeys(['B1','B2','B3','B4'],5)
    for r in data:
        assert all(r['dimensions'][n]['score'] in [0,1,2] for n in dims)
        allrows.append({'platform':platform,**r})
    review=base/(platform+' block v1.0')/'Second review comparison v1.0/Second review report.md'
    if review.exists():sources[str(review)]=sha(review)
assert len({r['id'] for r in allrows})==120
oxfolder=base/'OxAlpha partial block v1.0/Lead assessment v1.0'
for n,h in json.loads((oxfolder/'manifest.json').read_text())['files'].items():
    assert sha(oxfolder/n)==h;verified+=1
sources[str(oxfolder/'assessment.json')]=sha(oxfolder/'assessment.json')
for rel in ['00 Method/Session 2 Experiment A - Collection closure confirmed - 2026-09-24.md','05 Analysis/Session 2 Experiment A - DO NOT SUBMIT/GPT block v1.0/Rubric.md','05 Analysis/Session 2 Experiment A - DO NOT SUBMIT/Post-DeepSeek review and stopping rationale - 2026-09-23.md']:
    sources[str(root/rel)]=sha(root/rel)
def counts(rows):
    c=Counter(r['decision'] or 'unresolved_category_correct_ids_wrong_fare' for r in rows)
    return dict(c)
def table_counts(rows):
    c=counts(rows)
    return '|'.join(str(c.get(n,0)) for n in ['optimal correct','invalid choice','incomplete/ambiguous','unresolved_category_correct_ids_wrong_fare'])
byplatform={p:counts([r for r in allrows if r['platform']==p]) for p in platforms}
bycondition={c:counts([r for r in allrows if r['condition']==c]) for c in ['B1','B2','B3','B4']}
dist={c:{n:dict(Counter(r['dimensions'][n]['score'] for r in allrows if r['condition']==c)) for n in dims} for c in ['B1','B2','B3','B4']}
optimal=[r for r in allrows if r['decision']=='optimal correct']
optimal_assurance=Counter(r['dimensions']['assurance']['score'] for r in optimal)
out.mkdir(parents=True,exist_ok=False)
(out/'Analysis data.json').write_text(json.dumps({'at':at,'status':'descriptive_lead_synthesis_second_review_incomplete','complete_block_count':6,'complete_block_responses':120,'balanced_counts':counts(allrows),'by_platform':byplatform,'by_condition':bycondition,'dimension_distributions':dist,'optimal_decision_assurance_distribution':dict(optimal_assurance),'source_hashes':sources,'records':allrows},indent=2,ensure_ascii=False),encoding='utf-8')
md='''# Experiment A — cross-platform analysis v1.0

Status: descriptive synthesis of unblinded lead assessments. DeepSeek and OxAlpha second assessment remains pending. Earlier lead and second scores remain separate; disagreements are not adjudicated. No composite, statistical significance test or universal reliability estimate is reported.

## Decision and scope

Collection closed after DeepSeek. The operator confirmed on 24 September 2026 that no random extra platform would be added, and authorized analysis. The resource/value judgment is recorded in the collection-closure decision and three logs. It is post-result and does not establish saturation or the absence of unseen failure variants.

Experiment A withheld the policy and BIGL. It compares four prompt conditions on one fixed feasible synthetic task: B1 ad hoc/unconstrained, B2 PDCA, B3 CIPDA+ROMER, B4 prescribed six-stage workflow. The historical term unstructured means ad hoc/unconstrained; spontaneous structure is allowed and is not a treatment violation. B1 still receives the full constrained task. This experiment does not compare structured versus literally structure-free text.

The correct result is O1/R1 at EUR460. Eligible-leg pair totals are 460, 510, 500, 550; permitted totals are 460 and 500. Arrival limit is 12 October 07:30, return departure limit 14 October 19:00, both inclusive. O1 provides 105 minutes before the conference and 15 minutes slack against its deadline. R1 exactly meets the 120-minute return margin.

## Coverage and whole-response decisions

Six complete blocks contribute 120 evaluable responses, five per condition per platform. Mistral includes one transparently recorded A02 replacement after a blocked original attempt. Counts concern decisions under the frozen rubric, not complete compliance or explanation quality.

|Platform/interface block|Evaluable|Optimal correct|Invalid choice|Incomplete/ambiguous|Category unresolved: correct IDs, wrong fare|
|---|---:|---:|---:|---:|---:|
'''
for p in platforms:md+='|'+p+'|20|'+table_counts([r for r in allrows if r['platform']==p])+'|\n'
md+='|Total|120|'+table_counts(allrows)+'|\n'
md+='''
DeepSeek B4 R04 selects correct O1/R1 IDs but repeatedly states EUR220+EUR240=EUR400, including in verification and final recommendation. It does not meet the frozen optimal definition, which requires EUR460. Its selected itinerary does not breach a hard constraint, so calling it invalid choice would also misapply the rubric. The original categories do not expressly cover this case: keep its category unresolved and record the arithmetic defect separately. Relabelling this one case does not change the 114 strictly optimal count. A broader correct-closing-ID count is a different outcome and must not replace the frozen measure.

OxAlpha is excluded from balanced totals: one substantive B2 R01 response is optimal after explicit correction, one B3 R01 provider error is technical, and 18 slots were unsubmitted. Gemini's single captured inability response and frozen block are separate; its other slots do not become observed failures. Qwen Chat, Poe, Kimi and Chat ZAI remain untested with no assigned outcomes.

|Condition|Evaluable|Optimal correct|Invalid choice|Incomplete/ambiguous|Category unresolved|
|---|---:|---:|---:|---:|---:|
'''
for c in ['B1','B2','B3','B4']:md+='|'+c+'|30|'+table_counts([r for r in allrows if r['condition']==c])+'|\n'
md+='''
B2 has 30/30 optimal decisions in this collected task, but its explanations and checks are not uniformly accurate. B4 has no observed hard-constraint-invalid selected itinerary, yet contains the persistent EUR400 arithmetic error and several false or unsupported assurance claims. These descriptive counts do not establish a winning framework. Prompt packages differ in length, explicit instructions and output requirements, and platform modes differ. No inference should attribute differences uniquely to an acronym or operating discipline.

## Separate dimensions

The following cells give counts at score 0 / 1 / 2, each totaling 30. Zero combines absent and materially incorrect findings according to the source reason codes; it is not automatically an error count. Two means sufficient support on that dimension, not a fully compliant run. No dimension sums or overall pass scores are calculated.

|Condition|Constraint explanation|Fare arithmetic|Evidence linkage|Reconstruction|Uncertainty|Assurance|
|---|---|---|---|---|---|---|
'''
for c in ['B1','B2','B3','B4']:md+='|'+c+'|'+'|'.join(' / '.join(str(dist[c][n].get(s,0)) for s in [0,1,2]) for n in dims)+'|\n'
md+=f'''
Among the 114 optimal decisions, lead assurance ratings are 0 for {optimal_assurance[0]}, 1 for {optimal_assurance[1]}, and 2 for {optimal_assurance[2]}. This is direct evidence in the collected assessments that correct selection and well-supported assurance are different outcomes. It is not a new composite measure, and reviewer differences below limit the strength of any threshold-based summary.

## Evidence patterns and contrasts

1. **Correct decisions can rest on defective explanations.** Mistral repeatedly excludes the eligible previous-evening O3 option, often while still choosing the optimum. Its 15 false O3 exclusions occur in B1 (4), B2 (5), B3 (4) and B4 (2). This is a local contrast favoring B4 for that particular defect, not proof of a general effect. Correct output alone would conceal the problem.
2. **Initial error, explicit correction and unresolved contradiction are different.** DeepSeek B3 R01/R04 explicitly retract the initial O2 recommendation; B1 R05 explicitly reverses false infeasibility. DeepSeek B3 R05 and Copilot B1 R01 leave incompatible actionable recommendations without explicit retraction. OxAlpha B2 R01 explicitly corrects its initial invalid answer. These should not be collapsed into either all failures or all clean passes.
3. **Verification language is not independent evidence of verification quality.** DeepSeek B4 R04 repeats the same wrong addition through comparison, verification, ROMER and completion, then reports no open exceptions. The response with the clearest intended-action entries in that block still makes this error. A detailed record can expose a defect without preventing it.
4. **More constrained output often exposes more assessable evidence, but adherence is uneven.** GPT B1 frequently lacks comparative fare evidence; its B3 responses supply fuller support. Some B4 responses across platforms omit stage intentions, the scorecard, supporting references or the trace claimed by the scorecard. Headings and checkmarks alone cannot establish the required function, nor can visible presentation establish internal action order. B1 sometimes spontaneously supplies all eight filters and all four totals, as DeepSeek demonstrates.
5. **Authority and provenance are distinct from itinerary correctness.** Grok B4 R01 and B3 R04 have captured prohibited web-search evidence and contradictory no-search assurances. Copilot's search-invocation statement is self-reported and unconfirmed; it must not be counted as another observed search. Invented airport identities and transfer assumptions also occur in earlier assessments.
6. **The assessors themselves vary.** Earlier second reviews agree on sampled decisions while disagreeing on how false margin claims, contradictory currencies or unsupported process claims affect particular scores. Some second-review rationales contain mistakes. Independent checking must itself remain auditable.

## Review coverage and disagreement

The prospectively fixed minimum sample is R01 in each condition; it is not a random sample of failures. Original lead scores were withheld from the second assessor, but treatment instructions were visible. All completed second reviews are separate AI assessments, not independent human validation.

|Block|Second-reviewed records|Decision agreements|Dimension agreements|Dimension differences|
|---|---:|---:|---:|---:|
|GPT|4|4/4|22/24|2|
|Grok|4|4/4|17/24|7|
|Mistral|4|4/4|21/24|3|
|Lumo|4|4/4|20/24|4|
|Copilot|4|4/4|14/24|10|
|DeepSeek|0|Pending|Pending|Pending|

Across completed reviews, 94/120 individual dimension comparisons agree and 26 differ; this is a descriptive tally, not a reliability statistic. Functional disagreements are retained in the five source comparison reports and are not folded into these counts. No forced consensus or score overwrite is performed. The fixed sample misses both Mistral invalid R03 responses, Copilot's invalid R03, and DeepSeek B3 R05/B4 R04. It cannot validate all 120 responses or the salient failures. A supplementary failure-focused review would need its own explicit label and would not replace R01 coverage.

DeepSeek's prepared fixed four-record packet and OxAlpha's prepared sole-substantive-record packet contain original requests, responses and the frozen rubric, with lead judgments withheld. No new external reviewer submission has occurred during this analysis. DeepSeek B4 R04 category interpretation remains open; any later adjudication must preserve the original assessment and document the rule rather than silently recode it.

## What this supports for the paper

Suggested bounded finding: Across six complete platform/interface blocks on one fixed synthetic itinerary task, the lead assessor classified 114 of 120 responses as optimal under the frozen whole-response definition. Three selected invalid itineraries, two contained unresolved contradictory actionable choices, and one selected the correct IDs with an incorrect total that fell outside the rubric's expressly defined categories. Correct selection frequently coexisted with deficient explanation or assurance. Procedural prompts produced assessable records but did not ensure accurate checks, complete adherence or reliable self-certification. These are descriptive observations; the policy itself was withheld and its effectiveness was not tested.

The findings support treating decision quality, evidence quality, authority boundaries and assurance as distinct governance concerns. They provide examples motivating verifiable records and external checking. They do not establish that the proposed policy, BIGL, CIPDA or any framework causes improved general reliability. No general ranking of providers, model families or prompt conditions follows from this single task.

## Limitations and remaining work

- One feasible closed-data case does not test blocked inputs, missing information, genuinely infeasible tasks, real booking actions or a range of business-impact levels.
- Five repetitions per condition are within platform/interface settings, not independent provider/model samples. Backend identity is not consistently exposed; six platforms must not be described as six independent architectures.
- Same matched order, repeated task content, differing modes, collection dates, interruptions and replacements constrain comparisons. The lead executed and assessed the work unblinded and had seen prior results.
- Scope was changed after results, including stopping after DeepSeek. Technical interruptions, refusal/inability, unsubmitted slots and substantive mistakes remain separate. Remaining-platform outcomes are unknown.
- Separate dimension scores involve interpretation. The five completed second-review reports preserve differences; DeepSeek and OxAlpha review is incomplete. No scores were reconciled merely to improve agreement.
- Complete the two pending second assessments, preserve both ratings and document any explicit adjudication before describing analysis as review-complete. No further target-platform collection is needed to perform those steps.

## Audit trail

'''
md+=f'Recorded {at}. Reverified {verified} lead-analysis manifest files across six complete blocks and the OxAlpha partial assessment. The earlier five lead score sets were read without mutation. The new DeepSeek/OxAlpha assessment step separately reverified 220 sealed raw evidence hashes and DeepSeek frozen request hashes. Source paths and SHA256 values are retained in Analysis data.json and Source manifest.json. Original target evidence remains untouched.\n\n'
md+='Primary sources:\n\n'
for p in sources:md+='- ['+Path(p).name+' — '+Path(p).parent.parent.name+'](<'+p.replace('\\','/')+'>)\n'
(out/'Analysis report.md').write_text(md,encoding='utf-8')
(out/'Source manifest.json').write_text(json.dumps({'at':at,'files':sources,'verified_lead_manifest_files':verified},indent=2),encoding='utf-8')
hashes={str(p.relative_to(out)):sha(p) for p in out.iterdir() if p.is_file()}
(out/'manifest.json').write_text(json.dumps({'at':at,'files':hashes},indent=2),encoding='utf-8')
for n,h in hashes.items():assert sha(out/n)==h
entry=f'\n\n## {at} — Experiment A cross-platform synthesis v1.0\nCollection remains closed. Balanced set: 120 responses across six complete blocks; lead counts {json.dumps(counts(allrows))}. OxAlpha partial block and Gemini inability remain separate. Analysis report: {out / "Analysis report.md"}. SHA256: {sha(out / "Analysis report.md")}. Earlier five score sets preserved, {verified} lead-analysis file hashes reverified. No composite or inferential platform ranking. Twenty fixed records have completed second review; DeepSeek four R01 and OxAlpha sole substantive R01 remain pending. One DeepSeek category edge case retained unresolved. No external reviewer submission, extra platform test, forced consensus or policy-effectiveness claim.\n'
for rel in ['08 Logs/Generation 3 Session 2/Session record.md','08 Logs/Generation 3 Session 2/Recipient and run register.md','08 Logs/chronology.md']:
    with (root/rel).open('a',encoding='utf-8') as f:f.write(entry)
    assert sha(out/'Analysis report.md') in (root/rel).read_text(encoding='utf-8')
print(json.dumps({'report':str(out/'Analysis report.md'),'counts':counts(allrows),'conditions':bycondition,'optimal_assurance':dict(optimal_assurance),'verified_analysis_files':verified,'dimension_distributions':dist},indent=2))
