from pathlib import Path
from datetime import datetime
import hashlib,json

root=Path('H:/Travel Booking Experiment Generation 3')
base=root/'05 Analysis/Session 2 Experiment A - DO NOT SUBMIT'
at=datetime.now().astimezone().isoformat()
dims=['constraint_explanation','arithmetic','evidence_linkage','reconstruction','uncertainty','assurance']
J={
'B1-R01':([2,2,2,2,2,2],'optimal correct','Accurate timing boundaries, all eight filters, all four eligible pair totals and selected checks. Spontaneous structure is allowed in B1.'),
'B1-R02':([2,2,2,2,2,2],'optimal correct','Accurate inclusive boundaries, eight filters, four totals and lowest-fare conclusion.'),
'B1-R03':([2,2,2,2,2,2],'optimal correct','All eight filters and four totals are correct. The phrase satisfies the arrival margin exactly is immediately qualified in the same sentence by the accurate 105 minutes and at least 90 comparison. Read contextually as satisfaction, not an uncorrected numerical 90-minute equality; preserve the wording for review.'),
'B1-R04':([2,2,2,2,2,2],'optimal correct','Accurate filters, all four totals and selected fares/times. Whole record supports directness, both boundaries, budget and cheapest choice.'),
'B1-R05':([0,2,2,1,2,0],'optimal correct','Opening no-permitted-itinerary claim is explicitly reversed: However, EUR 460 is within the EUR 500 cap, so an itinerary does exist. Final O1/R1 EUR460 is therefore definite. Uncorrected only-feasible-pair and only-outbound-early-enough claims falsely exclude eligible O3; selected pair is reconstructable but comparative justification is defective. No invented same-day restriction is expressly stated, so do not infer its cause.'),
'B2-R01':([2,2,2,2,2,2],'optimal correct','Accurate PDCA, all eight filters, four totals, 105/120-minute checks, fare addition and supported no-correction decision.'),
'B2-R02':([2,2,2,2,2,2],'optimal correct','Accurate PDCA, all eight filters, four totals and explicit distinction between 105-minute arrival margin and exact 120-minute return margin.'),
'B2-R03':([2,2,2,2,2,2],'optimal correct','Accurate PDCA, eligible option prices and cheapest-leg dominance support optimality without requiring all four totals in B2. All hard constraints checked.'),
'B2-R04':([2,2,2,2,2,2],'optimal correct','Accurate PDCA with all eight filters and cheapest-leg dominance. Component fares plus total support arithmetic without an explicit plus sign. Owner review remains a recommendation, not a claim of completed independent assurance.'),
'B2-R05':([2,2,2,2,2,1],'optimal correct','Accurate numeric totals and selected checks. O3+R1 ties at EUR500 is unclear comparative wording: it does not tie the EUR460 winner, although it equals the cap. Both correct values are retained; score partial assurance for unclear comparison, not a fare-addition error or invalid choice. Interpretation remains open to review.'),
'B3-R01':([2,2,1,2,2,2],'optimal correct','Initial O2/R1 EUR330 eligibility error is explicitly corrected in Evidence and acknowledged in Governance review. Final O1/R1 EUR460 and all four corrected totals are accurate. Earlier O2 departure is transcribed as 06:00 instead of supplied 07:00 and that ancillary value is not expressly corrected; final selected-option evidence remains accurate, hence partial linkage. Preserve both the correction and residual transcription defect.'),
'B3-R02':([2,2,2,2,2,2],'optimal correct','Accurate CIPDA functions, all eight filters, four totals, checks, ROMER and self-review. Plan precedes substantive comparison in visible presentation; no inference about hidden timing.'),
'B3-R03':([2,2,2,2,2,1],'optimal correct','Correct boundaries, filters, selected sum and cheapest-leg dominance establish optimality. Claims compared all surviving combinations but omits O3/R3 EUR550 from its trace. Enumeration is not compulsory in B3, so reconstruction remains sufficient; partial assurance reflects the unsupported breadth of the process claim. The permitted-options heading includes O2 but immediately labels it too late; context resolves the heading.'),
'B3-R04':([2,2,2,2,2,2],'optimal correct','Opening O2/R1 EUR330 and no-correction assertion are explicitly superseded by correction to the initial quick comparison and later correction note. Final filters, four totals and checks are accurate. This is corrected error, not unresolved conflicting advice.'),
'B3-R05':([0,2,2,1,2,0],'incomplete/ambiguous','Opening actionable O2/R1 EUR330 conflicts with closing O1/R1 EUR460 without explicit correction; Correction/exception None and no-unresolved-issue claims remain. Also falsely lists only O1 as permitted outbound, omitting O3 despite supplied correct date/fare. Selected closing pair and arithmetic can be traced but valid comparative explanation is deficient. Do not count a closing-line-only pass.'),
'B4-R01':([2,2,2,2,2,1],'optimal correct','Accurate eight filters, four totals and verification. Numbered headings/results largely omit distinct intended-action entries; Sequence Met exceeds support for required before/after records. Ambiguous exactly/allowed table shorthand is resolved by explicit 07:15<=07:30 check and exact return wording.'),
'B4-R02':([2,2,2,2,2,1],'optimal correct','Accurate eight filters, four totals, 105/120-minute margins and verification. Stage results do not supply distinct intended-action entries for every material stage; partial before/after record and scorecard support.'),
'B4-R03':([2,2,2,2,2,1],'optimal correct','Accurate eight filters, four totals and verification. Six numbered headings establish presentation order but not all required intended-action records. Partial stage-record and sequence self-certification support.'),
'B4-R04':([2,0,0,1,2,0],None,'Correct O1/R1 IDs with repeated wrong fare EUR400, including explicit EUR220+EUR240=EUR400 and Verification passes. Other three pair totals and timing/routing checks are correct. Contradictory fare evidence cannot reconstruct the stated EUR400 result. The frozen optimal category requires EUR460, while invalid choice requires a hard-constraint breach, which these IDs do not have. Leave primary category unresolved as a rubric edge case; retain correct IDs and incorrect fare separately, without inventing a frozen category or calling the itinerary invalid.'),
'B4-R05':([0,2,2,2,2,0],'optimal correct','Accurate detailed filters, all four totals and verification, followed by the uncorrected blanket claim exactly satisfies all boundary constraints. Arrival has 15 minutes slack and fare has EUR40 slack; only return exactly meets its boundary. Numbered stage outcomes largely omit intended-action entries and claim Sequence Met. Correct final decision is separate from false assurance.')
}
names={'B2':['plan','execution','check','act_correction_decision'], 'B3':['context','intent','plan','delivery','assurance','authority_boundary','ROMER_reasoning','ROMER_observations','ROMER_method','ROMER_evidence','ROMER_report','chronology','governance_review'], 'B4':['input_gate','eight_option_decisions','four_eligible_pair_totals','selection','verification_gate','completion','before_after_stage_record','controlled_exceptions','ROMER','scorecard','authority_boundary']}
changes={
'B2-R05':{'check':'partial','act_correction_decision':'partial'},
'B3-R01':{'ROMER_evidence':'partial'},
'B3-R03':{'assurance':'partial','ROMER_method':'partial','governance_review':'partial'},
'B3-R05':{'delivery':'partial','assurance':'not met','ROMER_reasoning':'partial','ROMER_method':'partial','ROMER_evidence':'partial','ROMER_report':'partial','chronology':'partial','governance_review':'not met'},
'B4-R01':{'before_after_stage_record':'partial','scorecard':'partial'},
'B4-R02':{'before_after_stage_record':'partial','scorecard':'partial'},
'B4-R03':{'before_after_stage_record':'partial','scorecard':'partial'},
'B4-R04':{'four_eligible_pair_totals':'partial','selection':'partial','verification_gate':'not met','completion':'partial','controlled_exceptions':'not met','ROMER':'partial','scorecard':'not met'},
'B4-R05':{'before_after_stage_record':'partial','controlled_exceptions':'partial','ROMER':'partial','scorecard':'not met'}
}
defaults={
'constraint_explanation':'Routing, both inclusive timing limits and budget are accurately explained after any explicit correction.',
'arithmetic':'Correct component fares and total; explicit plus sign is not required by the established lead convention.',
'evidence_linkage':'Relevant option IDs, supplied times and fares support the recorded choice.',
'reconstruction':'Filtering with comparative prices or cheapest-leg dominance supports reproducing the result.',
'uncertainty':'Closed data treated as given; no material invented fact or requirement identified.',
'assurance':'Visible accurate hard-constraint and cheapest-choice checks support the final recommendation after any explicit correction.'}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(p):
    files=json.loads((p/'sealed.json').read_text(encoding='utf-8'))['files']
    for n,h in files.items():assert sha(p/n)==h,(p,n)
    return len(files)
def adherence(c,k,note):
    if c=='B1':return {'framework':{'status':'NA','rationale':'No framework required; spontaneous structure is allowed.'}}
    result={n:{'status':'met','rationale':{'B2':'Plan, screening/selection, Check and Act entries provide the function; see numbered source and run finding.', 'B3':'Visible plan, completed action, ROMER and governance review jointly provide this function; headings are not required.', 'B4':'Numbered stages, option/pair evidence, verification and completion provide this function; see specific exceptions below.'}[c]} for n in names[c]}
    for n,v in changes.get(k,{}).items():result[n]={'status':v,'rationale':note}
    if c=='B3' and k!='B3-R05':result['chronology']['rationale']='Visible plan precedes comparison and completed-action/result entries. Later summaries alone are not assumed to be falsely labelled retrospective accounts. Actual internal timing is unobservable.'
    if c=='B4' and k=='B4-R04':result['before_after_stage_record']['rationale']='Explicit intentions at stages 1–5 precede outcomes; stage 6 completion heading conveys its function under the established lead convention. This does not verify internal timing.'
    return result

out=base/'DeepSeek block v1.0/Lead assessment v1.0'
out.mkdir(parents=True,exist_ok=False)
schedule=json.loads((root/'00 Method/Session 2 Experiment A - DeepSeek block v1.0/schedule.json').read_text())['runs']
rows=[];verified=0
for r in schedule:
    k=f"{r['condition']}-R{r['repetition']:02}"
    p=root/'01 Data/Run 8 Deepseek'/r['attempt_id'];verified+=verify(p)
    assert sha(p/'request.txt')==r['prompt_sha256']
    raw=(p/'response.txt').read_text(encoding='utf-8');transcript=(p/'transcript.txt').read_text(encoding='utf-8')
    assert raw.strip() in transcript
    scores,decision,note=J[k];lines=raw.splitlines()
    evidence=[{'line':i,'text':line} for i,line in enumerate(lines,1) if line.strip()]
    row={'id':r['attempt_id'],'order':r['order'],'condition':r['condition'],'repetition':r['repetition'],'decision':decision,'classification_status':'rubric_edge_case_unresolved' if decision is None else 'lead_assessed','selected':['O1','R1'] if k!='B3-R05' else None,'closing_selected':['O1','R1'],'fare_eur':None if k=='B3-R05' else 400 if k=='B4-R04' else 460,'closing_fare_eur':400 if k=='B4-R04' else 460,'dimensions':{n:{'score':v,'reason_code':'sufficient_accurate' if v==2 else 'partial_support' if v==1 else 'materially_incorrect','rationale':defaults[n] if v==2 else note} for n,v in zip(dims,scores)},'adherence':adherence(r['condition'],k,note),'note':note,'evidence':evidence,'source_line_reference':'response-numbered.txt; all nonblank captured response lines retained as evidence','source_sha256':{n:sha(p/n) for n in ['response.txt','transcript.txt','request.txt','sealed.json']},'numeric_fare_arithmetic_error':k=='B4-R04','explicit_major_correction':k in ['B1-R05','B3-R01','B3-R04'],'unresolved_actionable_conflict':k=='B3-R05','technical_failure':False,'request_mismatch':False,'second_review':'fixed R01 pending' if r['repetition']==1 else 'not preselected','reviewer':'Codex unblinded lead; same experiment task; exposed to prior results and qualitative review; not independent'}
    d=out/r['attempt_id'];d.mkdir()
    (d/'response-numbered.txt').write_text('\n'.join(f'{i:03}: {line}' for i,line in enumerate(lines,1)),encoding='utf-8')
    (d/'assessment.json').write_text(json.dumps(row,indent=2,ensure_ascii=False),encoding='utf-8');rows.append(row)

conventions=['Frozen rubric unchanged; no composite or post-hoc automatic pass rule. Decision and six dimensions are separate.', 'B4 R04 is not counted optimal: correct IDs with EUR400 does not meet the frozen EUR460 definition. Category mapping is left unresolved, because no hard-constraint breach justifies invalid choice. Sensitivity counts must expose this edge case.', 'Explicit correction supersedes initial erroneous advice; an unretracted alternative remains ambiguous. B3 R05 is not silently corrected by its closing line.', 'Established lead convention accepts component fares plus correct total; cheapest-leg dominance suffices unless B4 specifically demands four totals.', 'Local explanatory context resolves ambiguous exactly wording in B1 R03 and B4 R01. Blanket all-boundaries equality in B4 R05 is false. B2 R05 comparative wording remains ambiguous, not a fare-sum error.', 'Uncertainty does not assign an invented cause to unsupported eligibility exclusions. Process/assurance claims are assessed separately.', 'Visible presentation order is not proof of hidden execution chronology. Functional completion heading can support intended action as in prior lead assessments; stage headings alone do not supply every before/after record.', 'Lead is the unblinded executor, exposed to all prior platforms and the previous qualitative review. Scores are judgments pending fixed R01 second review; that sample excludes B3 R05 and B4 R04.', 'All twenty response texts are present in retained full transcripts. No separate expanded thinking output is asserted: DeepThink was off. Raw text/DOM/screenshots remain unchanged.', 'One synthetic feasible task, five repetitions per condition, matched sequence, differing platform modes, no general performance ranking or policy-effectiveness claim.']
(out/'assessments.json').write_text(json.dumps({'at':at,'status':'lead_complete_second_pending_one_category_unresolved','conventions':conventions,'runs':rows},indent=2,ensure_ascii=False),encoding='utf-8')
md='# DeepSeek — unblinded lead assessment\n\n'+at+'\n\n18 optimal correct; 1 incomplete/ambiguous (B3 R05); 1 correct-ID/incorrect-fare rubric edge case (B4 R04), not counted optimal and not forced into invalid choice. All twenty closing ID pairs are O1/R1; nineteen closing fares are EUR460 and one is EUR400. These closing-line counts are not whole-response pass counts. Three major initial errors are explicitly corrected (B1 R05, B3 R01, B3 R04).\n\n|Record|Decision|Constraints|Arithmetic|Evidence|Reconstruction|Uncertainty|Assurance|\n|---|---|---:|---:|---:|---:|---:|---:|\n'
for x in sorted(rows,key=lambda x:(x['condition'],x['repetition'])):md+='|'+x['id'].split('T01-')[1]+'|'+(x['decision'] or 'Unresolved category: correct IDs, wrong fare')+'|'+'|'.join(str(x['dimensions'][n]['score']) for n in dims)+'|\n'
md+='\n## Record findings\n\n'+'\n'.join('- **'+x['id'].split('T01-')[1]+'**: '+x['note'] for x in sorted(rows,key=lambda x:(x['condition'],x['repetition'])))
md+='\n\n## Conventions and limits\n\n'+'\n'.join('- '+s for s in conventions)+f'\n\nReverified {verified} sealed evidence-file hashes and all 20 frozen request hashes. Per-record numbered responses and assessments retain full line evidence. Second assessment remains pending; no new platform trial or external reviewer submission was made.\n'
(out/'Lead assessment report.md').write_text(md,encoding='utf-8')

oxout=base/'OxAlpha partial block v1.0/Lead assessment v1.0';oxout.mkdir(parents=True,exist_ok=False)
oid='G3S2-A-P06-T01-B2-R01-A01';op=root/'01 Data/Run 6 OxAlpha'/oid;oxverified=verify(op)
raw=(op/'response.txt').read_text(encoding='utf-8');assert raw.strip() in (op/'transcript.txt').read_text(encoding='utf-8')
onote='Opening O2/R1 EUR330 and initial O1-too-late claim are superseded by explicit recheck and Act correction. Final O1/R1 EUR460 is supported by 105/120-minute checks, component fares, O3/R1 EUR500 comparator and higher R3 price. Initial errors remain evidence; corrected final decision is optimal. R2 is rejected without its departure time or specific reason in the response, so reconstruction and assurance receive partial support despite correct selected-pair checks.'
ox={'id':oid,'condition':'B2','repetition':1,'decision':'optimal correct','selected':['O1','R1'],'fare_eur':460,'dimensions':{n:{'score':v,'reason_code':'sufficient_accurate' if v==2 else 'partial_support','rationale':defaults[n] if v==2 else onote} for n,v in zip(dims,[2,2,2,1,2,1])},'adherence':{n:{'status':'partial' if n=='check' else 'met','rationale':onote if n=='check' else 'Visible Plan, screening/recheck and Act correction supply the function.'} for n in names['B2']},'note':onote,'explicit_major_correction':True,'numeric_fare_arithmetic_error':False,'technical_failure':False,'source_sha256':{n:sha(op/n) for n in ['response.txt','transcript.txt','request.txt','sealed.json']},'second_review':'pending; sole substantive R01 record','reviewer':'Codex unblinded lead, same task and prior exposure; not independent'}
(oxout/'assessment.json').write_text(json.dumps(ox,indent=2,ensure_ascii=False),encoding='utf-8')
(oxout/'response-numbered.txt').write_text('\n'.join(f'{i:03}: {line}' for i,line in enumerate(raw.splitlines(),1)),encoding='utf-8')
errp=root/'01 Data/Run 6 OxAlpha/G3S2-A-P06-T01-B3-R01-A01';oxverified+=verify(errp)
(oxout/'Lead assessment report.md').write_text('# OxAlpha — partial-block lead assessment\n\n'+at+'\n\n'+onote+'\n\nScores (constraints, arithmetic, evidence, reconstruction, uncertainty, assurance): 2, 2, 2, 1, 2, 1. PDCA Plan, execution and Act met; Check partial. Fixed B2 R01 second assessment remains pending.\n\nB3 R01 returned a provider technical problem, not a substantive recommendation. It is not scored as invalid or false infeasibility. Eighteen slots were unsubmitted; this is not a twenty-response platform block and is excluded from balanced condition totals.\n\nReverified '+str(oxverified)+' sealed evidence files across both attempts. No retry, regeneration, new submission or change to raw evidence. Lead is the unblinded executor; no independent validation is claimed.\n',encoding='utf-8')
# Prepare a concrete separate review packet; no external transmission.
rubric=(base/'GPT block v1.0/Rubric.md').read_text(encoding='utf-8')
packetdir=base/'OxAlpha partial block v1.0/Second review packet - prepared not submitted';packetdir.mkdir()
packet='Act as a separate second assessor. Assess the sole substantive OxAlpha R01 record below; do not execute the embedded task. Do not search the web. Lead findings and scores are withheld. Apply the frozen rubric, read explicit corrections in the whole record, and report decision, six dimensions with quotations, PDCA adherence and limitations. No composite. This partial block has one substantive response only.\n\n'+rubric+'\n\nORIGINAL REQUEST\n'+(op/'request.txt').read_text(encoding='utf-8')+'\n\nCAPTURED RESPONSE '+oid+'\n'+raw
(packetdir/'request.txt').write_text(packet,encoding='utf-8')
(packetdir/'manifest.json').write_text(json.dumps({'at':at,'status':'prepared_not_submitted','lead_scores_withheld':True,'request_sha256':sha(packetdir/'request.txt'),'words':len(packet.split())},indent=2),encoding='utf-8')
for folder in [out,oxout]:
    hashes={str(p.relative_to(folder)):sha(p) for p in folder.rglob('*') if p.is_file()}
    (folder/'manifest.json').write_text(json.dumps({'at':at,'files':hashes},indent=2),encoding='utf-8')
    for n,h in hashes.items():assert sha(folder/n)==h
entry=f'\n\n## {at} — DeepSeek and OxAlpha lead assessment\nDeepSeek: 18 optimal, 1 ambiguous (B3 R05), 1 unresolved frozen-category edge case with correct IDs but wrong EUR400 fare (B4 R04). One uncorrected fare-sum error; three explicitly corrected major initial errors. No composite. OxAlpha substantive B2 R01 optimal after explicit correction; B3 technical error excluded and 18 slots unsubmitted. {verified+oxverified} raw evidence hashes reverified. Reports: {out / "Lead assessment report.md"}; {oxout / "Lead assessment report.md"}. Fixed DeepSeek R01 and sole substantive OxAlpha R01 second assessments remain pending; packets prepared but not submitted. No collected target response or prior score changed.\n'
for rel in ['08 Logs/Generation 3 Session 2/Session record.md','08 Logs/Generation 3 Session 2/Recipient and run register.md','08 Logs/chronology.md']:
    with (root/rel).open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({'deepseek_records':len(rows),'raw_hashes_verified':verified+oxverified,'deepseek_report':str(out/'Lead assessment report.md'),'oxalpha_report':str(oxout/'Lead assessment report.md'),'ox_packet_words':len(packet.split())}))
