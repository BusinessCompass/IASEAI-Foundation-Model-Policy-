from pathlib import Path
from datetime import datetime
import json,hashlib,shutil

root=Path('H:/Travel Booking Experiment Generation 3')
base=root/'05 Analysis/Session 2 Experiment A - DO NOT SUBMIT'
local=Path('E:/AAll XPlain/Air Trial Experiments and paper/Session Records')
support=base/'Analysis support - 2026-09-24'
support.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
packets=[]
for platform,folder,datafolder,ids in [
    ('DeepSeek','DeepSeek block v1.0','Run 8 Deepseek',[f'G3S2-A-P08-T01-B{c}-R01-A01' for c in range(1,5)]),
    ('OxAlpha','OxAlpha partial block v1.0','Run 6 OxAlpha',['G3S2-A-P06-T01-B2-R01-A01'])]:
    d=base/folder/'Second review packet - prepared not submitted';p=d/'request.txt'
    manifest=json.loads((d/'manifest.json').read_text())
    assert sha(p)==manifest['request_sha256']
    body=p.read_text(encoding='utf-8')
    for ident in ids:
        source=root/'01 Data'/datafolder/ident
        assert ident in body
        assert (source/'request.txt').read_text(encoding='utf-8').strip() in body
        assert (source/'response.txt').read_text(encoding='utf-8').strip() in body
    packets.append({'platform':platform,'path':str(p),'sha256':sha(p),'words':len(body.split()),'verified_records':ids,'status':'prepared_not_submitted'})
scripts={}
for name in ['close_collection_2026_09_24.py','assess_deepseek_oxalpha_2026_09_24.py','synthesize_experiment_a_2026_09_24.py','audit_analysis_2026_09_24.py']:
    shutil.copyfile(local/name,support/name)
    assert sha(local/name)==sha(support/name)
    scripts[name]=sha(support/name)
report=base/'Cross-platform synthesis v1.0 - 2026-09-24/Analysis report.md'
for rel in ['08 Logs/Generation 3 Session 2/Session record.md','08 Logs/Generation 3 Session 2/Recipient and run register.md','08 Logs/chronology.md']:
    assert sha(report) in (root/rel).read_text(encoding='utf-8')
audit={'at':datetime.now().astimezone().isoformat(),'report_sha256':sha(report),'matching_report_references_in_logs':3,'packets':packets,'scripts':scripts,'external_submission':'none; authorization question pending','original_target_evidence':'read only; unchanged'}
(support/'Verification.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
print(json.dumps(audit,indent=2))
