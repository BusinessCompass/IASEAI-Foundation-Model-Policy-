from pathlib import Path
from datetime import datetime
import json,hashlib,shutil
root=Path('H:/Travel Booking Experiment Generation 3')
base=root/'05 Analysis/Session 2 Experiment A - DO NOT SUBMIT/Copilot block v1.0'
lead=base/'Lead assessment v1.0';review=base/'Second review ChatGPT A01'
for d,m in [(lead,'manifest.json'),(review,'sealed.json')]:
 for n,h in json.loads((d/m).read_text())['files'].items():assert hashlib.sha256((d/n).read_bytes()).hexdigest()==h
rows=json.loads((lead/'assessments.json').read_text(encoding='utf-8'))['runs']
dims=['constraint_explanation','arithmetic','evidence_linkage','reconstruction','uncertainty','assurance']
# Manual transcription of reviewer tables, without adjudication.
scores={'B1':[2,2,1,1,2,1],'B2':[2,2,2,2,2,2],'B3':[1,2,2,2,1,2],'B4':[2,2,2,2,1,2]}
functions={
'B1':{'framework':'NA'},
'B2':dict.fromkeys(['plan','execution','check','act_correction_decision'],'met'),
'B3':dict.fromkeys(['context','intent','plan','delivery','assurance','authority_boundary','ROMER_reasoning','ROMER_observations','ROMER_method','ROMER_evidence','ROMER_report','chronology','governance_review'],'met'),
'B4':dict.fromkeys(['input_gate','eight_option_decisions','four_eligible_pair_totals','selection','verification_gate','completion','before_after_stage_record','ROMER'],'met')|{'controlled_exceptions':'partial','scorecard':'partial'}}
diff=[];fdiff=[];records=[]
for c,vals in scores.items():
 r=next(x for x in rows if x['condition']==c and x['repetition']==1)
 records.append({'id':r['id'],'lead_decision':r['decision'],'second_decision':'incomplete/ambiguous' if c=='B1' else 'optimal correct','second_scores':dict(zip(dims,vals)),'lead_scores':{n:r['dimensions'][n]['score'] for n in dims}})
 for n,v in zip(dims,vals):
  if v!=r['dimensions'][n]['score']:diff.append({'record':c+'-R01','dimension':n,'lead':r['dimensions'][n]['score'],'second':v,'status':'unresolved'})
 for n,v in functions[c].items():
  if v!=r['adherence'][n]['status']:fdiff.append({'record':c+'-R01','function':n,'lead':r['adherence'][n]['status'],'second':v,'status':'unresolved'})
assert len(diff)==10 and len(fdiff)==5
at=datetime.now().astimezone().isoformat();out=base/'Second review comparison v1.0';out.mkdir(exist_ok=False)
cautions=[
'B1 decision agreement does not mean score agreement: second penalizes evidence/reconstruction for the conflicting headline but retains correct constraint explanation; lead locates the contradiction in constraints/assurance while crediting reconstructable body evidence. Both preserve the unretracted invalid headline.',
'B2 both identify dollar symbols substituted for EUR in the visible summary. Lead treats contradictory units as Evidence 0 and Assurance 1; second credits correct main evidence/checks at 2/2 and records the unit defect separately. This remains an unresolved rubric interpretation.',
'B3 second treats informal after-19:00 wording as a contradiction and lowers constraints to 1. Lead reads it with explicit exact-boundary acceptance and retains 2. Second also lowers uncertainty to 1 for generated system-instruction claims; lead records those claims as unverified metadata without treating them as invented task facts.',
'B4 both identify unverified search invocation and conflicting scope/no-exception claims. Lead lowers assurance to 0; second retains itinerary assurance 2 and lowers uncertainty to 1, allocating the process defect mainly to adherence. Neither establishes an actual executed search.',
'B4 reviewer calls every stage an intended-action record, although stage 6 uses a completion heading rather than an explicit intended-action sentence. Both credit functional sufficiency; this agreement does not establish hidden chronology.',
'B3 reviewer groups all five ROMER functions as Met and explicitly says all are present; comparison maps this grouped finding to five keys. B4 authority has narrative discussion but no discrete rating: not imputed or counted as agreement/disagreement.',
'Reviewer technical/request-mismatch terminology describes an unverified process claim. All source/submitted prompt checks passed; no technical transmission mismatch or technical exclusion is established.',
'Four fixed R01 records were reviewed, not all 20. This separate AI assessment is not independent human validation. No follow-up, regeneration, consensus forcing or original-score overwrite occurred.']
data={'at':at,'status':'fixed_second_review_complete_disagreements_unresolved','reviewer':'ChatGPT GPT-5.6 Sol Medium, fresh Unpersonalized temporary chat','exposure':'Frozen rubric and four fixed R01 prompts/responses, condition labels visible, lead scores withheld','authorization':'User yes to exact Copilot packet disclosure to ChatGPT','decision_agreement':4,'decision_comparisons':4,'dimension_agreement':14,'dimension_comparisons':24,'records':records,'dimension_disagreements':diff,'second_functions':functions,'functional_disagreements':fdiff,'functional_compared':sum(map(len,functions.values())),'unrated':['B4 authority_boundary: narrative only'],'cautions':cautions,'adjudication':'None; both original assessments preserved','raw_review_sha256':hashlib.sha256((review/'response.txt').read_bytes()).hexdigest()}
(out/'comparison.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
raw=(review/'response.txt').read_text(encoding='utf-8')
(out/'second-review-numbered.txt').write_text('\n'.join(f'{i:03}: {s}' for i,s in enumerate(raw.splitlines(),1)),encoding='utf-8')
md=f'# Copilot — second assessment comparison\n\n{at}\n\nThe four fixed R01 records were reviewed once by ChatGPT GPT-5.6 Sol at Medium effort in a fresh Unpersonalized temporary chat. Lead scores were withheld; condition labels were visible.\n\nDecision agreement: 4/4 — B1 incomplete/ambiguous; B2, B3 and B4 optimal correct. Dimension agreement: 14/24. Ten dimension differences and five rated functional differences remain unresolved. No composite or forced consensus. The 20-record lead classification remains 18 optimal, 1 invalid, 1 ambiguous; the invalid B1 R03 was outside the fixed sample.\n\n|Record|Dimension|Lead|Second|\n|---|---|---:|---:|\n'
for d in diff:md+=f"|{d['record']}|{d['dimension']}|{d['lead']}|{d['second']}|\n"
md+='\n## Functional differences\n\n|Record|Function|Lead|Second|\n|---|---|---|---|\n'
for d in fdiff:md+=f"|{d['record']}|{d['function']}|{d['lead']}|{d['second']}|\n"
md+='\n## Interpretation and limits\n\n'+'\n'.join('- '+x for x in cautions)
md+='\n\n## Evidence status\n\nAll 42 lead-assessment file hashes and 9 second-review evidence hashes reverified. Exact approved packet hash verified; submitted text matched after whitespace normalization. Raw review, transcript, DOM, preflight, request, composer and completion metadata are sealed on H:. No screenshot was captured for this review. Copilot target collection, lead assessment and minimum second review are complete. Next reserve in the recorded order is OxAlpha.\n'
(out/'Second review report.md').write_text(md,encoding='utf-8')
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}
(out/'manifest.json').write_text(json.dumps({'at':at,'files':hashes},indent=2),encoding='utf-8')
for n,h in hashes.items():assert hashlib.sha256((out/n).read_bytes()).hexdigest()==h
support=base/'Assessment support - 2026-09-23';support.mkdir(exist_ok=False)
for n in ['score_lead.py','seal_review.py','compare_review.py']:shutil.copy2(Path(__file__).parent/n,support/n)
entry=f'\n\n## {at} — Copilot minimum second review complete\nFour fixed R01 records reviewed. Decision agreement 4/4; dimension agreement 14/24; ten dimension and five functional differences preserved unresolved. One B4 authority function has narrative only, not imputed. Lead and second originals unchanged; no forced consensus. Raw review (9 files) and lead assessment (42 files) hashes reverified. Comparison: {out / "Second review report.md"}. Copilot collection/lead/minimum second review complete. Next reserve: OxAlpha (P06).\n'
for n in ['08 Logs/Generation 3 Session 2/Session record.md','08 Logs/Generation 3 Session 2/Recipient and run register.md','08 Logs/chronology.md']:
 with (root/n).open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({'decision_agreement':'4/4','dimension_agreement':'14/24','functional_differences':len(fdiff),'report':str(out/'Second review report.md')}))
