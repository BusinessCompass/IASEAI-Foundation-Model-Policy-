from pathlib import Path
import json,hashlib,shutil
from datetime import datetime
root=Path('H:/Travel Booking Experiment Generation 3')
base=root/'05 Analysis/Session 2 Experiment A - DO NOT SUBMIT/Copilot block v1.0'
local=Path(__file__).parent.parent/'Copilot-second-review'
norm=lambda s:' '.join(s.split())
assert norm((local/'request.txt').read_text(encoding='utf-8'))==norm((local/'submitted-visible.txt').read_text(encoding='utf-8'))
packet=base/'Second review packet - awaiting destination approval'
assert hashlib.sha256((local/'request.txt').read_bytes()).hexdigest()==json.loads((packet/'manifest.json').read_text())['request_sha256']
assert json.loads((local/'completion.json').read_text())['request_verified']
at=datetime.now().astimezone().isoformat()
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in local.iterdir() if p.is_file()}
with (local/'sealed.json').open('x',encoding='utf-8') as f:json.dump({'at':at,'files':hashes},f,indent=2)
dest=base/'Second review ChatGPT A01';shutil.copytree(local,dest)
for n,h in hashes.items():assert hashlib.sha256((dest/n).read_bytes()).hexdigest()==h
entry=f'\n\n## {at} — Copilot second review captured\nUser authorized the exact Copilot R01 packet to ChatGPT. Sent once in fresh Unpersonalized temporary chat, GPT-5.6 Sol Medium; lead scores withheld, condition labels visible. {len(hashes)} evidence files sealed and verified on H: at {dest}. Full review preserved; comparison pending. No target response or lead score overwritten.\n'
for n in ['08 Logs/Generation 3 Session 2/Session record.md','08 Logs/Generation 3 Session 2/Recipient and run register.md','08 Logs/chronology.md']:
 with (root/n).open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({'verified':len(hashes),'destination':str(dest)}))
