# Experiment A — cross-platform analysis v1.2 editorial draft

Editorial status: revised wording for operator review; analytical results and review completion are unchanged. This draft preserves v1.1 as the archived final version while editorial review continues.

Status: collection closed; lead assessment complete; minimum planned second-review coverage complete; descriptive analysis finalized with disagreements and limitations explicitly retained. Lead and second scores remain separate. No composite, statistical significance test or universal reliability estimate is reported.

## Decision and scope

Collection closed after DeepSeek. The operator confirmed on 24 September 2026 that no random extra platform would be added, and authorized analysis. The resource/value judgment is recorded in the collection-closure decision and three logs. It is post-result and does not establish saturation or the absence of unseen failure variants.

Experiment A withheld the policy and BIGL. It compares four prompt conditions on one fixed feasible synthetic task: B1 ad hoc/unconstrained, B2 PDCA, B3 CIPDA+ROMER, B4 prescribed six-stage workflow. The historical term unstructured means ad hoc/unconstrained; spontaneous structure is allowed and is not a treatment violation. B1 still receives the full constrained task. This experiment does not compare structured versus literally structure-free text.

The correct result is O1/R1 at EUR460. Eligible-leg pair totals are 460, 510, 500, 550; permitted totals are 460 and 500. Arrival limit is 12 October 07:30, return departure limit 14 October 19:00, both inclusive. O1 provides 105 minutes before the conference and 15 minutes slack against its deadline. R1 exactly meets the 120-minute return margin.

## Coverage and itinerary-decision classifications

Six complete blocks contribute 120 evaluable responses, five per condition per platform. Mistral includes one transparently recorded A02 replacement after a blocked original attempt. Counts concern itinerary decisions under the frozen rubric; explanation and assurance were scored separately. The whole response was read to detect unresolved contradictory actionable choices, not to require flawless explanation or assurance.

|Platform/interface block|Evaluable|Optimal correct|Invalid choice|Incomplete/ambiguous|Rubric exception: correct IDs, wrong fare|
|---|---:|---:|---:|---:|---:|
|GPT|20|20|0|0|0|
|Grok|20|20|0|0|0|
|Mistral|20|18|2|0|0|
|Lumo|20|20|0|0|0|
|Copilot|20|18|1|1|0|
|DeepSeek|20|18|0|1|1|
|Total|120|114|3|2|1|

DeepSeek B4 R04 selects correct O1/R1 IDs but repeatedly states EUR220+EUR240=EUR400, including in verification and final recommendation. It does not meet the frozen optimal definition, which requires EUR460. Its selected itinerary does not breach a hard constraint, so calling it invalid choice would also misapply the rubric. Final disposition: report this case separately as a rubric exception, with correct IDs and incorrect fare, rather than force an unsuitable category. Preserve the original lead classification as unassigned and the arithmetic defect as explicit. This is a final reporting limitation, not unfinished data collection or a pending adjudication task. The 114 strictly optimal count is unchanged. A broader correct-closing-ID count is a different outcome and must not replace the frozen measure.

OxAlpha is excluded from balanced totals: one substantive B2 R01 response is optimal after explicit correction, one B3 R01 provider error is technical, and 18 slots were unsubmitted. Gemini's single captured inability response and frozen block are separate; its other slots do not become observed failures. Qwen Chat, Poe, Kimi and Chat ZAI remain untested with no assigned outcomes.

|Condition|Evaluable|Optimal correct|Invalid choice|Incomplete/ambiguous|Rubric exception|
|---|---:|---:|---:|---:|---:|
|B1|30|27|2|1|0|
|B2|30|30|0|0|0|
|B3|30|28|1|1|0|
|B4|30|29|0|0|1|

B2 has 30/30 optimal decisions in this collected task, but its explanations and checks are not uniformly accurate. B4 has no observed hard-constraint-invalid selected itinerary, yet contains the persistent EUR400 arithmetic error and several false or unsupported assurance claims. These descriptive counts do not establish a winning framework. Prompt packages differ in length, explicit instructions and output requirements, and platform modes differ. No inference should attribute differences uniquely to an acronym or operating discipline.

## Separate dimensions

The following cells give counts at score 0 / 1 / 2, each totaling 30. Zero combines absent and materially incorrect findings according to the source reason codes; it is not automatically an error count. Two means sufficient support on that dimension, not a fully compliant run. No dimension sums or overall pass scores are calculated.

|Condition|Constraint explanation|Fare arithmetic|Evidence linkage|Reconstruction|Uncertainty|Assurance|
|---|---|---|---|---|---|---|
|B1|8 / 0 / 22|0 / 5 / 25|0 / 5 / 25|1 / 13 / 16|4 / 0 / 26|10 / 6 / 14|
|B2|8 / 0 / 22|0 / 1 / 29|1 / 1 / 28|0 / 6 / 24|8 / 0 / 22|8 / 7 / 15|
|B3|10 / 0 / 20|0 / 0 / 30|2 / 1 / 27|0 / 6 / 24|5 / 0 / 25|12 / 5 / 13|
|B4|9 / 0 / 21|1 / 1 / 28|1 / 2 / 27|0 / 4 / 26|3 / 0 / 27|11 / 10 / 9|

Among the 114 optimal decisions, lead assurance ratings are 0 for 35, 1 for 28, and 2 for 51. This is direct evidence in the collected assessments that correct selection and well-supported assurance are different outcomes. It is not a new composite measure, and reviewer differences below limit the strength of any threshold-based summary.

## Evidence patterns and contrasts

1. **Correct decisions can rest on defective explanations.** Mistral repeatedly excludes the eligible previous-evening O3 option, often while still choosing the optimum. Its 15 false O3 exclusions occur in B1 (4), B2 (5), B3 (4) and B4 (2). This is a local contrast favoring B4 for that particular defect, not proof of a general effect. Correct output alone would conceal the problem.
2. **Initial error, explicit correction and unresolved contradiction are different.** DeepSeek B3 R01/R04 explicitly retract the initial O2 recommendation; B1 R05 explicitly reverses false infeasibility. DeepSeek B3 R05 and Copilot B1 R01 leave incompatible actionable recommendations without explicit retraction. OxAlpha B2 R01 explicitly corrects its initial invalid answer. These should not be collapsed into either all failures or all clean passes.
3. **Verification language is not independent evidence of verification quality.** DeepSeek B4 R04 repeats the same wrong addition through comparison, verification, ROMER and completion, then reports no open exceptions. The response with the clearest intended-action entries in that block still makes this error. A detailed record can expose a defect without preventing it.
4. **More constrained output often exposes more assessable evidence, but adherence is uneven.** GPT B1 frequently lacks comparative fare evidence; its B3 responses supply fuller support. Some B4 responses across platforms omit stage intentions, the scorecard, supporting references or the trace claimed by the scorecard. Headings and checkmarks alone cannot establish the required function, nor can visible presentation establish internal action order. B1 sometimes spontaneously supplies all eight filters and all four totals, as DeepSeek demonstrates.
5. **Authority and provenance are distinct from itinerary correctness.** Grok B4 R01 and B3 R04 have captured prohibited web-search evidence and contradictory no-search assurances. Copilot's search-invocation statement is self-reported and unconfirmed; it must not be counted as another observed search. Invented airport identities and transfer assumptions also occur in earlier assessments.
6. **The assessors themselves vary.** Earlier second reviews agree on sampled decisions while disagreeing on how false margin claims, contradictory currencies or unsupported process claims affect particular scores. Some second-review rationales contain mistakes. Independent checking must itself remain auditable.

## Completed second-review coverage and retained disagreement

The fixed minimum sample remains R01 in each of the four conditions. All six complete blocks now have their four R01 responses second-assessed (24 records), and OxAlpha's sole substantive B2 R01 response has also been second-assessed (one separate partial-block record). No target trial was repeated to obtain a preferred outcome. Lead scores were withheld; treatment instructions were visible. These are separate AI assessments, not independent human validation.

|Block|Second-reviewed records|Decision agreements|Dimension agreements|Dimension differences|
|---|---:|---:|---:|---:|
|GPT|4|4/4|22/24|2|
|Grok|4|4/4|17/24|7|
|Mistral|4|4/4|21/24|3|
|Lumo|4|4/4|20/24|4|
|Copilot|4|4/4|14/24|10|
|DeepSeek|4|4/4|21/24|3|
|Six complete blocks|24|24/24|115/144|29|
|OxAlpha partial block, separate|1|0/1|4/6|2|

Counts are descriptive comparisons, not a reliability coefficient. Functional ratings and their differences are retained in the source comparison reports and are not mixed into the six-dimension totals. Neither the lead nor the second assessor is treated as infallible. Disagreements are retained as final reportable findings; completing review does not require forcing agreement.

OxAlpha's second assessor calls the response incomplete/ambiguous even while acknowledging that the wrong opening O2/R1 recommendation is explicitly corrected. Lead classification remains optimal after correction under the previously recorded convention. Both classifications are reported. The second reviewer scores reconstruction and assurance 2 versus lead 1, and Check Met versus lead Partial. Its statement that every rejection has an explicit reason overstates the R2 rejection mark in the source. This partial-block disagreement does not change balanced-set totals.

DeepSeek's full comparison report records its four decisions, all six scores and functional differences. Both completed new reviews used GPT-5.6 Sol at Medium effort in fresh Unpersonalized temporary chats. The UI stated that memory, plugins and custom instructions were ignored. A first DeepSeek reviewer attempt in an older tab displayed Latest 5.3 and produced no visible substantive answer for about five minutes; the executor stopped it, preserved it as A01, then submitted the identical frozen packet once in a fresh current-model session as A02. No substantive reviewer answer was discarded, and no target DeepSeek response was regenerated. The cause of the older-tab stall is not established as a provider failure.

The fixed sample does not include the two invalid Mistral R03 responses, Copilot's invalid R03, or DeepSeek B3 R05/B4 R04. Minimum review coverage therefore does not independently validate every response or every notable failure. The DeepSeek wrong-fare case remains a lead-only observation outside the fixed sample and is reported as a final rubric exception. No retrospective sample substitution was made.

## What this supports for the paper

Suggested bounded finding: Across six complete platform/interface blocks on one fixed synthetic itinerary task, the lead assessor classified 114 of 120 responses as containing an optimal itinerary decision—O1/R1 at EUR460 with no unresolved contradictory actionable choice—with explanation and assurance scored separately. Three selected invalid itineraries, two contained unresolved contradictory actionable choices, and one selected the correct IDs with an incorrect total that fell outside the rubric's expressly defined categories. Correct selection frequently coexisted with deficient explanation or assurance. Procedural prompts produced assessable records but did not ensure accurate checks, complete adherence or reliable self-certification. These are descriptive observations; the policy itself was withheld and its effectiveness was not tested.

The findings support treating decision quality, evidence quality, authority boundaries and assurance as distinct governance concerns. They provide examples motivating verifiable records and external checking. They do not establish that the proposed policy, BIGL, CIPDA or any framework causes improved general reliability. No general ranking of providers, model families or prompt conditions follows from this single task.

## Final limitations

- One feasible closed-data case does not test blocked inputs, missing information, genuinely infeasible tasks, real booking actions or a range of business-impact levels.
- Five repetitions per condition are within platform/interface settings, not independent provider/model samples. Backend identity is not consistently exposed; six platforms must not be described as six independent architectures.
- Same matched order, repeated task content, differing modes, collection dates, interruptions and replacements constrain comparisons. The lead executed and assessed the work unblinded and had seen prior results.
- Scope was changed after results, including stopping after DeepSeek. Technical interruptions, refusal/inability, unsubmitted slots and substantive mistakes remain separate. Remaining-platform outcomes are unknown.
- Separate dimension scores involve interpretation. The completed second-review reports preserve differences; DeepSeek and OxAlpha review is complete; their disagreements are retained. No scores were reconciled merely to improve agreement.
- Final reporting uses separate lead and second ratings with explicit disagreements. The wrong-fare rubric exception is disclosed rather than hidden in another category. No required second assessment remains outstanding under the recorded minimum design.

## Final audit and closure

Recorded 2026-09-24T10:02:40.190132+02:00. Finalization reverified 356 source analysis/review files against their manifests. Original target evidence and prior lead/second scores remain unchanged. This report supersedes v1.0 for current status; historical pending labels and preparation-time manifests remain preserved and are not current status indicators.

Evidence sources and SHA256 values are in the archived v1.1 Source manifest.json. the archived v1.1 Analysis data.json contains all 120 lead records and the new second-review comparisons. Review evidence folders include exact packets, submission checks, full responses, transcripts, DOM, screenshots and reviewer settings. Collection closure and analysis closure are separate recorded events; both are now complete within the agreed design.

- [DeepSeek second-review comparison](<H:/Travel Booking Experiment Generation 3/05 Analysis/Session 2 Experiment A - DO NOT SUBMIT/DeepSeek block v1.0/Second review comparison v1.0/Second review report.md>)
- [OxAlpha second-review comparison](<H:/Travel Booking Experiment Generation 3/05 Analysis/Session 2 Experiment A - DO NOT SUBMIT/OxAlpha partial block v1.0/Second review comparison v1.0/Second review report.md>)


## Editorial revision — point 1

Clarified that optimal classifies the itinerary decision, with explanation and assurance scored separately. Replaced the ambiguous whole-response definition wording and coverage heading. No counts, scores, rubric rules, evidence, or review judgments changed. Source: H:\Travel Booking Experiment Generation 3\05 Analysis\Session 2 Experiment A - DO NOT SUBMIT\Cross-platform synthesis v1.1 FINAL - 2026-09-24\Analysis report.md

