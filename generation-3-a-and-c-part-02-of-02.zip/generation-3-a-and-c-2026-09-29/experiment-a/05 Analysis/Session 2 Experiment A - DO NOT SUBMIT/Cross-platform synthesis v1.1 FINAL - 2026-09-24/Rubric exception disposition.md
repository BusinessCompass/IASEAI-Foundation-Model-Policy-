# Final disposition of the DeepSeek wrong-fare rubric exception

Record: G3S2-A-P08-T01-B4-R04-A01.

Observed facts: selected O1/R1, whose supplied fares are EUR220 and EUR240; repeatedly reports EUR400, including the explicit sum and verification. Correct total is EUR460. IDs identify the unique cheapest feasible itinerary; the reported fare is wrong and verification claim is materially false.

The frozen optimal category requires EUR460. Invalid choice requires a hard-constraint breach; the selected IDs do not breach one. No new category is silently inserted into the frozen rubric. Final reporting retains one separately described rubric exception, excluded from the 114 optimal count. Original unassigned category and dimension ratings remain unchanged. The exception is visible in denominators and narrative; it is not dropped from the 120-response dataset.

This closes the reporting decision without claiming the categorical ambiguity was independently adjudicated. The record was outside the fixed R01 second-review sample. It remains a lead-only finding, and that limitation is retained in the final report. A future study should prospectively specify an incorrect-fare category or a separate exact-output measure.
