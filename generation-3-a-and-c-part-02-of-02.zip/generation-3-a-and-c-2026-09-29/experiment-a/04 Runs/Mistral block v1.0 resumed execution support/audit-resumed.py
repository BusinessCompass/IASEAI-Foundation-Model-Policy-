from pathlib import Path
from datetime import datetime
import json,hashlib,collections,shutil
root=Path('H:/Travel Booking Experiment Generation 3');local=Path(__file__).parent
method=root/'00 Method/Session 2 Experiment A - Mistral block v1.0';log=root/'08 Logs/Generation 3 Session 2'
runs=json.loads((method/'schedule.json').read_text())['runs']
ledger=[json.loads(s) for s in (log/'Mistral block execution.jsonl').read_text().splitlines()]
good=[r for r in ledger if r['status']=='captured_hash_verified'];failed=[r for r in ledger if r['status']=='platform_message_limit_no_response']
assert len(ledger)==21 and len(good)==20 and len(failed)==1
assert failed[0]['id']=='G3S2-A-P03-T01-B4-R03-A01'
expected=[r['attempt_id'] for r in runs];expected[10]=expected[10].replace('A01','A02')
assert [r['id'] for r in good]==expected
for n,h in json.loads((method/'freeze-manifest.json').read_text())['files'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h
counts=collections.Counter();hash_count=0
for i,r in enumerate(good):
 p=root/'01 Data/Run 3 Vibe'/r['id'];counts[runs[i]['condition']]+=1
 for n,h in json.loads((p/'sealed.json').read_text())['files'].items():
  assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h;hash_count+=1
 assert hashlib.sha256((p/'request.txt').read_bytes()).hexdigest()==runs[i]['prompt_sha256']
 assert json.loads((p/'completion.json').read_text())['request_verified']
assert sorted(counts.values())==[5,5,5,5]
bad=root/'01 Data/Run 3 Vibe'/failed[0]['id']
bad_hashes=json.loads((bad/'sealed.json').read_text())['files']
for n,h in bad_hashes.items():assert hashlib.sha256((bad/n).read_bytes()).hexdigest()==h
at=datetime.now().astimezone().isoformat()
data={'at':at,'status':'capture_complete_scoring_pending','scheduled_slots':20,'completed_responses':20,'attempts':21,'technical_no_response':1,'replacements':1,'conditions':dict(counts),'response_evidence_hashes_verified':hash_count,'technical_evidence_hashes_verified':len(bad_hashes),'frozen_sources_verified':True,'mode':'Mistral web Chat Fast; backend unavailable','runs':good,'technical_attempts':failed}
with (log/'Mistral block completion audit - 2026-09-22.json').open('x',encoding='utf-8') as f:json.dump(data,f,indent=2)
md=f'''# Mistral block capture completed

Verified {at}. All 20 scheduled slots now have a completed response, five per condition. {hash_count} completed-response evidence hashes and {len(bad_hashes)} technical-attempt hashes verified on H:, together with unchanged frozen source files.

21 total attempts: 19 first-attempt completed responses, one first attempt blocked by message limit with no response, and its single A02 replacement completed. The blocked B4 R03 A01 remains preserved and non-evaluable. B4 R03 A02 fills slot 11. Resume followed the rate-limit break and operator instruction; personalization OFF reverified. Each response captured before resetting to a visibly empty Incognito chat, Chat Fast. Exact backend and complete hidden-context isolation unavailable.

Policy and BIGL withheld. Original prompts and schedule order preserved. No corrective reruns for substantive errors. Formal rubric scoring and preselected R01 second review remain pending; capture completion alone does not establish governance success or reliability. Response files retain UI timestamps and occasional feedback controls; exclude those transparently only in derived analysis.

'''+ '\n'.join(f"- Slot {r['order']}: {r['id']}" for r in good)+'\n'
with (log/'Mistral block completion audit - 2026-09-22.md').open('x',encoding='utf-8') as f:f.write(md)
support=root/'04 Runs/Mistral block v1.0 resumed execution support';support.mkdir(exist_ok=False)
for p in local.iterdir():
 if p.is_file():
  shutil.copy2(p,support/p.name);assert hashlib.sha256(p.read_bytes()).hexdigest()==hashlib.sha256((support/p.name).read_bytes()).hexdigest()
for p in [log/'Session record.md',log/'Recipient and run register.md',root/'08 Logs/chronology.md']:
 with p.open('a',encoding='utf-8') as f:f.write('\n\n'+md)
print(json.dumps({k:v for k,v in data.items() if k not in ['runs','technical_attempts']}))
