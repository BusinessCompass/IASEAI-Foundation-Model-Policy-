from pathlib import Path
import sys,json,hashlib,shutil
from datetime import datetime
local=Path(__file__).parent;root=Path('H:/Travel Booking Experiment Generation 3')
sys.path.insert(0,str(local.parent/'G3S2-browser-fix-v0.2'))
import evidence_guard as g
method=root/'00 Method/Session 2 Experiment A - Mistral block v1.0'
for n,h in json.loads((method/'freeze-manifest.json').read_text())['files'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h
r=json.loads((method/'schedule.json').read_text())['runs'][10]
old=root/'01 Data/Run 3 Vibe'/r['attempt_id']
for n,h in json.loads((old/'sealed.json').read_text())['files'].items():assert hashlib.sha256((old/n).read_bytes()).hexdigest()==h
assert json.loads((old/'technical-status.json').read_text())['assistant_message_count']==0
id=r['attempt_id'].replace('A01','A02')
g.prepare(local,id,r['condition'],(old/'request.txt').read_text(encoding='utf-8'),r['prompt_sha256'])
at=datetime.now().astimezone().isoformat()
record={'at':at,'slot':11,'original':r['attempt_id'],'replacement':id,'reason':'Original hit message limit and had zero assistant messages; later expired. Reset estimate passed; fresh chat available. Operator authorized continuation from 11.','settings':'Memories, Knowledge, Localisation OFF reverified; Fast unchanged; backend unavailable','source_hash':r['prompt_sha256'],'original_preserved':True}
with (method/'Slot 11 replacement authorization.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
shutil.copy2(local/'resume-settings.txt',method/'resume-settings.txt')
entry='\n\n## '+at+' — Mistral resumed at slot 11\n'+json.dumps(record)+'\n'
for n in ['08 Logs/Generation 3 Session 2/Session record.md','08 Logs/Generation 3 Session 2/Recipient and run register.md','08 Logs/chronology.md']:
 with (root/n).open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps(record))
