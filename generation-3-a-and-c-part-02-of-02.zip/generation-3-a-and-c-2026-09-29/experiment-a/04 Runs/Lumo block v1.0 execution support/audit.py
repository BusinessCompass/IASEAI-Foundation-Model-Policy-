from pathlib import Path
from datetime import datetime
import json,hashlib,collections,shutil
root=Path('H:/Travel Booking Experiment Generation 3');local=Path(__file__).parent
method=root/'00 Method/Session 2 Experiment A - Lumo block v1.0'
runs=json.loads((method/'schedule.json').read_text())['runs']
ledger=[json.loads(s) for s in (root/'08 Logs/Generation 3 Session 2/Lumo block execution.jsonl').read_text().splitlines()]
assert len(ledger)==len(runs)==20
assert [r['id'] for r in ledger]==[r['attempt_id'] for r in runs]
for n,h in json.loads((method/'freeze-manifest.json').read_text())['files'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h
count=0
for r in runs:
 p=root/'01 Data/Run 4 Lumo'/r['attempt_id']
 for n,h in json.loads((p/'sealed.json').read_text())['files'].items():
  assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h;count+=1
 assert hashlib.sha256((p/'request.txt').read_bytes()).hexdigest()==r['prompt_sha256']
 assert json.loads((p/'completion.json').read_text())['request_verified']
at=datetime.now().astimezone().isoformat();counts=dict(collections.Counter(r['condition'] for r in runs));assert sorted(counts.values())==[5,5,5,5]
log=root/'08 Logs/Generation 3 Session 2'
data={'at':at,'status':'capture_complete_scoring_pending','count':20,'conditions':counts,'order_verified':True,'evidence_hashes_verified':count,'replacements':0,'model':'Lumo 2.0 Max Thinking; exact backend unavailable','runs':ledger}
with (log/'Lumo block completion audit - 2026-09-23.json').open('x',encoding='utf-8') as f:json.dump(data,f,indent=2)
md=f'# Lumo target block completion\n\nVerified {at}.\n\n20/20 scheduled runs captured in order; five per condition. All {count} evidence hashes and all frozen files verified on H:. No replacement attempts. Lumo 2.0 Max Thinking mode; exact backend model unavailable. Fresh Ghost chats; memory OFF and personalization cleared temporarily with authorization. Web search enabled unchanged. Original profile restoration required.\n\nPreflight and account-setting actions are excluded. Only frozen task/intervention prompts were submitted, with policy and BIGL withheld. Responses are preserved unchanged, including any incorrect explanations. Full rubric scoring and separate second assessment of R01 per condition remain pending. No general reliability or equivalence conclusion follows from capture completion.\n\n'
md+='\n'.join(f"- {r['order']}: {r['attempt_id']}" for r in runs)+'\n'
with (log/'Lumo block completion audit - 2026-09-23.md').open('x',encoding='utf-8') as f:f.write(md)
support=root/'04 Runs/Lumo block v1.0 execution support';support.mkdir(exist_ok=False)
for p in local.iterdir():
 if p.is_file():
  shutil.copy2(p,support/p.name);assert hashlib.sha256(p.read_bytes()).hexdigest()==hashlib.sha256((support/p.name).read_bytes()).hexdigest()
entry=f'\n\n## {at} — Lumo target block capture completed\n20/20 scheduled P04 runs, five each B1-B4, captured in order and verified on H:. {count} evidence hashes verified; no replacements. Prior Lumo reviews excluded. Scoring and preselected second assessment pending. Completion audit: 08 Logs/Generation 3 Session 2/Lumo block completion audit - 2026-09-23.md/.json.\n'
for p in [log/'Session record.md',log/'Recipient and run register.md',root/'08 Logs/chronology.md']:
 with p.open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({k:v for k,v in data.items() if k!='runs'}))


