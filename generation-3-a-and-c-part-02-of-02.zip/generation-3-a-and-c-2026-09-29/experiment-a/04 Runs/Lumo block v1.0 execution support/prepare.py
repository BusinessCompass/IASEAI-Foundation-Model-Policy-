from pathlib import Path
from datetime import datetime
import json,hashlib,shutil,sys
root=Path('H:/Travel Booking Experiment Generation 3');local=Path(__file__).parent
sys.path.insert(0,str(local.parent/'G3S2-browser-fix-v0.2'))
import evidence_guard as g
source=root/'00 Method/Session 2 Experiment A - GPT block v1.0'
fm=json.loads((source/'freeze-manifest.json').read_text())
for n,h in fm['files'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h
method=root/'00 Method/Session 2 Experiment A - Lumo block v1.0';method.mkdir(exist_ok=False)
runs=json.loads((source/'schedule.json').read_text())['runs']
for r in runs:r['attempt_id']=r['attempt_id'].replace('P01','P04')
(method/'schedule.json').write_text(json.dumps({'design':'Same frozen matched order as prior platforms; no new randomization.','runs':runs},indent=2),encoding='utf-8')
protocol='''# Experiment A — Lumo block v1.0

Prospective freeze before P04 first submission, following GPT/Grok/Mistral observations. Four conditions, five repetitions, 20 slots; unchanged GPT frozen task/intervention prompts, rubric, reference and order. Data folder Run 4 Lumo. This is exploratory matched replication, not preregistration before all results.

Lumo Business web at lumo.proton.me: visible model Lumo 2.0 Max, Thinking mode selected. Preserve these settings; exact underlying model/version not exposed. This mode differs from prior platforms and is a documented confound, not a controlled model-family comparison. Web search enabled at preflight and left unchanged; no manual search invocation. Prohibited external use is a substantive finding, not a technical exclusion.

Fresh visibly empty Ghost chat each run; UI says disappears on close and never saved. Memory OFF observed. All four personalization fields blank; name/occupation temporarily cleared with explicit operator approval. Restore original exact values from preflight record after block or if testing is suspended. No project, Custom Lumo, files or extra context selected. Visible controls do not prove all hidden platform isolation.

Submit only exact corresponding SUBMIT prompt; withhold policy, BIGL, rubric, reference, labels and previous responses. Verify source SHA256 and normalized composer before exclusive send-intent and one send. Verify post-submission raw user text, allowing whitespace and rendered leading Markdown list markers only. Preserve source bytes and rendered text. Never blindly retry uncertain send.

Capture full response, submitted text, visible work/tool summaries, conversation-only DOM/text, viewport screenshot, timestamps and completion controls. Do not request hidden reasoning. Completion requires response action controls with no active generation. Seal/hash-verify each H: copy before resetting. Stop on settings/model/source changes or uncertain transmission. No corrections or regenerations for poor answers. At most one separately logged A02 replacement per technical failure after cause resolved; stop if replacement fails. Rate limits may require a recorded pause.

Apply unchanged rubric; decision, fare arithmetic, interpretation, assurance and adherence separate. No composite or inferential superiority claim. Lead unblinded. R01 of each condition preselected for separate second review, lead scores withheld, treatment unblinded; preserve disagreements. Report first attempts/recoveries, word counts and observed timings including overhead. One feasible case is insufficient for general reliability or infeasible-case claims. Five-platform roster fixed; no outcome-dependent substitution or early stopping.
'''
(method/'Protocol.md').write_text(protocol,encoding='utf-8')
pre=local.parent/'Lumo-preflight'
for n in ['personalization-observed.txt','personalization-cleared.txt','memory-observed.txt','model-observed.txt','tools-observed.txt']:shutil.copy2(pre/n,method/n)
for r in runs:
 p=root/'02 Primers/Session 2 Experiment A - GPT block v1.0'/r['prompt_file']
 g.prepare(local,r['attempt_id'],r['condition'],p.read_text(encoding='utf-8'),r['prompt_sha256'])
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in method.iterdir() if p.is_file()}
files.update({n:h for n,h in fm['files'].items() if n.startswith(('02 Primers','05 Analysis'))})
at=datetime.now().astimezone().isoformat()
(method/'freeze-manifest.json').write_text(json.dumps({'at':at,'files':files},indent=2),encoding='utf-8')
entry=f'\n\n## {at} — Lumo P04 frozen before first submission\n20 slots, unchanged prompts/rubric/reference/order. Lumo 2.0 Max Thinking, web search enabled unchanged; Ghost chats, memory OFF, personalization blank. Mode differences documented. Original profile restoration required after block or suspension. Policy/BIGL withheld. Freeze: {method}. No target submission yet.\n'
for n in ['08 Logs/Generation 3 Session 2/Session record.md','08 Logs/Generation 3 Session 2/Recipient and run register.md','08 Logs/chronology.md']:
 with (root/n).open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({'prepared':20,'freeze':str(method)}))
