from pathlib import Path
from datetime import datetime
import json,hashlib,shutil,sys
sys.path.insert(0,str(Path(__file__).parent.parent/'G3S2-browser-fix-v0.2'))
import evidence_guard as g
root=Path('H:/Travel Booking Experiment Generation 3');local=Path(__file__).parent
at=datetime.now().astimezone().isoformat()
method=root/'00 Method/Session 2 Experiment A - Grok block v1.0';method.mkdir(exist_ok=False)
source=root/'00 Method/Session 2 Experiment A - GPT block v1.0'
fm=json.loads((source/'freeze-manifest.json').read_text())
for n,h in fm['files'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h
runs=json.loads((source/'schedule.json').read_text())['runs']
for r in runs:r['attempt_id']=r['attempt_id'].replace('P01','P02')
(method/'schedule.json').write_text(json.dumps({'design':'Same frozen order as GPT for matched exploratory replication; not a new independent randomization.','runs':runs},indent=2),encoding='utf-8')
protocol='''# Experiment A — Grok target block v1.0

Prospective execution freeze for P02, case T01: four conditions, five repetitions, 20 scheduled slots. The common task and four exact prompts remain those frozen for GPT. Use the same scheduled condition order for matched replication. This follows GPT result inspection and Grok reference/second-review exposure; it is not preregistration before all observations.

Target: Grok web, Fast mode. Exact backend model is not exposed; do not invent it. Fresh visibly empty Private chat for each attempt. Preflight observed empty custom-instruction field and history personalization OFF. Preserve that dated evidence; it does not retrospectively establish earlier reviewer isolation. No policy, BIGL, reference, rubric, schedule, condition labels, prior responses or scores are submitted. Only exact frozen corresponding SUBMIT prompt goes to the target. Reviews remain outside this block.

Verify visible Fast mode and empty private chat before every submission. Keep prompt hashes, observed composer, exclusive send-intent and exact request bytes. Grok renders Markdown list prefixes: post-submission comparison may remove only line-leading list markers and normalize whitespace, retaining both raw source and rendered article. Any other difference is a technical mismatch; preserve and investigate. This is an explicit platform capture adaptation, not a prompt change.

Capture submitted article, full response, conversation text, DOM, screenshot and completion metadata. Expand visible work summaries when present; do not request hidden reasoning. Completion requires Copy response and no Stop model response. Screenshot is viewport corroboration; text and DOM are the complete primary record. Seal and hash-verify each H: copy before resetting. No clipboard capture or mutable current-condition variables.

Use explicit IDs/index checks. No corrective prompts/regenerations for poor answers. Retain technical failures separately; allow at most one A02 replacement after resolving the cause, then stop if replacement fails. Stop on settings/model/source change or uncertain submission. Never overwrite evidence or retry an uncertain send blindly.

Apply the unchanged frozen GPT rubric and reference. Lead first pass is unblinded. Preselect R01 of each condition for a separate second assessor; Grok must not act as its own independent reviewer. Retain disagreements. Report five scheduled/evaluable counts per condition, first-attempt and recovered outcomes, word counts and observed timings with overhead. No composite or significance/equivalence claims. One feasible case cannot establish general reliability or infeasible-case performance.

Platform roster: GPT, Grok, Mistral (existing Run 3 Vibe folder), Lumo, Gemini. Other seven platforms are reserved. Mistral folder mapping will be checked at its preflight; do not rename historic folders. Original GPT records remain unchanged.
'''
(method/'Protocol.md').write_text(protocol,encoding='utf-8')
for n in ['settings-observed.json','settings-observed.txt']:shutil.copy2(local/n,method/n)
for r in runs:
 p=root/'02 Primers/Session 2 Experiment A - GPT block v1.0'/r['prompt_file']
 g.prepare(local,r['attempt_id'],r['condition'],p.read_text(encoding='utf-8'),r['prompt_sha256'])
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in method.iterdir() if p.is_file()}
for n,h in fm['files'].items():
 if n.startswith('02 Primers') or n.startswith('05 Analysis'):files[n]=h
(method/'freeze-manifest.json').write_text(json.dumps({'at':at,'files':files},indent=2),encoding='utf-8')
roster=root/'00 Method/Session 2 Experiment A - Five platform roster - 2026-09-22.md'
with roster.open('x',encoding='utf-8') as f:f.write(f'''# Agreed initial five-platform roster

Recorded {at}, following the operator's proposed roster and instruction “OK. next”.

1. GPT — Run 1 GPT; 20-run target block complete.
2. Grok — Run 2 Grok; target block prepared, previous reviews excluded.
3. Mistral — planned mapping to existing Run 3 Vibe; verify service identity at preflight.
4. Lumo — Run 4 Lumo.
5. Gemini — Run 7 Gemini.

Roster fixed before further target results, after GPT results and Grok reviews. These are five platforms, not a claim of five independent model families. Record visible model/mode and stop on fallback/change. Other seven registered platforms remain reserved under scope amendment 01. No result-dependent substitution or early stopping on agreement.
''')
entry=f'\n\n## {at} — Five-platform roster fixed; Grok target prepared\nGPT, Grok, Mistral, Lumo and Gemini selected. Grok P02: 20 slots, Fast, fresh Private chats, history personalization observed off, custom field empty. Exact backend model unavailable. Same prompt hashes, rubric/reference and condition order as GPT. Freeze: 00 Method/Session 2 Experiment A - Grok block v1.0. Prior Grok reviews excluded. No target submission yet at freeze.\n'
for p in [root/'08 Logs/Generation 3 Session 2/Session record.md',root/'08 Logs/Generation 3 Session 2/Recipient and run register.md',root/'08 Logs/chronology.md']:
 with p.open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({'prepared':20,'freeze':str(method),'roster':str(roster)}))
