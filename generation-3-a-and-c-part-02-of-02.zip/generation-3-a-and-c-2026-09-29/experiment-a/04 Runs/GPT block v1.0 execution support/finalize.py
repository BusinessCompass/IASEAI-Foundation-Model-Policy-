from pathlib import Path
import sys,json,shutil,hashlib
from datetime import datetime
sys.path.insert(0,str(Path(__file__).parent.parent/'G3S2-browser-fix-v0.2'))
import evidence_guard as g
from PIL import Image
from io import BytesIO
root=Path('H:/Travel Booking Experiment Generation 3')
schedule=json.loads((root/'00 Method/Session 2 Experiment A - GPT block v1.0/schedule.json').read_text())['runs']
run=schedule[int(sys.argv[1])];p=Path(__file__).parent/run['attempt_id']
with Image.open(p/'raw-screenshot.jpg') as im:
 b=BytesIO();im.save(b,format='PNG')
g.capture(p,(p/'raw-submitted.txt').read_text(encoding='utf-8'),(p/'raw-transcript.txt').read_text(encoding='utf-8'),(p/'raw-dom.txt').read_text(encoding='utf-8'),b.getvalue(),True,True)
g.seal(p);assert g.verify_seal(p)
d=root/'01 Data/Run 1 GPT'/run['attempt_id'];shutil.copytree(p,d);assert g.verify_seal(d)
entry={'at':datetime.now().astimezone().isoformat(),'order':run['order'],'id':run['attempt_id'],'status':'captured_hash_verified','path':str(d)}
with (root/'08 Logs/Generation 3 Session 2/GPT block execution.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(entry)+'\n')
print(json.dumps(entry))
