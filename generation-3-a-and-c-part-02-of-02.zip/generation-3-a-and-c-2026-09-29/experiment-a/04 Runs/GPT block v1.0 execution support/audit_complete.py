from pathlib import Path
import json, hashlib, sys
from collections import Counter
from datetime import datetime
sys.path.insert(0,str(Path(__file__).parent.parent/'G3S2-browser-fix-v0.2'))
import evidence_guard as g
root=Path('H:/Travel Booking Experiment Generation 3')
logs=root/'08 Logs/Generation 3 Session 2'
method=root/'00 Method/Session 2 Experiment A - GPT block v1.0'
runs=json.loads((method/'schedule.json').read_text())['runs']
ledger=[json.loads(x) for x in (logs/'GPT block execution.jsonl').read_text().splitlines() if x.strip()]
assert len(runs)==len(ledger)==20
assert [r['attempt_id'] for r in runs]==[r['id'] for r in ledger]
assert [r['order'] for r in ledger]==list(range(1,21))
manifest=json.loads((method/'freeze-manifest.json').read_text())
for name,h in manifest['files'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
rows=[]
for r in runs:
 p=root/'01 Data/Run 1 GPT'/r['attempt_id']
 assert g.verify_seal(p),str(p)
 assert hashlib.sha256((p/'request.txt').read_bytes()).hexdigest()==r['prompt_sha256']
 completion=json.loads((p/'completion-observed.json').read_text())
 assert completion.get('request_verified',True)
 captured=json.loads((p/'captured.json').read_text())
 assert captured['status']=='captured' and not captured['problems']
 assert g.normal((p/'submitted-visible.txt').read_text(encoding='utf-8'))==g.normal((p/'request.txt').read_text(encoding='utf-8'))
 rows.append({'order':r['order'],'id':r['attempt_id'],'condition':r['condition'],'path':str(p),'seal_verified':True,'prompt_verified':True})
counts=dict(Counter(r['condition'] for r in runs))
assert all(v==5 for v in counts.values()) and len(counts)==4
at=datetime.now().astimezone().isoformat()
result={'at':at,'status':'capture_complete_scoring_pending','runs':20,'condition_counts':counts,'frozen_files_verified':len(manifest['files']),'schedule_order_verified':True,'replacement_attempts':0,'runs_verified':rows}
report='GPT block completion audit - 2026-09-22'
with (logs/(report+'.json')).open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
md=f'# GPT block v1.0 capture completion\n\nVerified {at}.\n\n20 of 20 scheduled responses captured in the frozen order; five per condition. All 20 evidence seals and prompt hashes verified on H:. All nine frozen protocol, prompt, reference and rubric file hashes remain unchanged. No replacement attempts were used.\n\nModel: GPT-5.6 Sol, Medium; fresh Unpersonalized temporary chats. Experiment A withheld the policy and BIGL tables. Raw transcripts, DOM records, submitted prompts, screenshots and completion observations are retained for each attempt.\n\nAudit implementation correction: B1-R01 and B4-R01 completion observations omit the later request_verified boolean. The initial audit stopped on that absent field before writing results. All 20 saved submitted prompts were then compared directly with request.txt using whitespace normalization, and captured.json status/problems checked; all passed. Original records were preserved unchanged.\n\nStatus: capture complete; rubric scoring and independent second scoring remain pending. This is an exploratory single-case block following engineering pilot exposure, not evidence of general reliability or completion of all recipients. The immutable schedule retains its original not_started fields; the execution ledger records actual completion.\n\n|Order|Attempt|Condition|Evidence seal|\n|---|---|---|---|\n'
for r in rows:md+=f"|{r['order']}|{r['id']}|{r['condition']}|Verified|\n"
with (logs/(report+'.md')).open('x',encoding='utf-8') as f:f.write(md)
entry=f'\n\n## {at} - GPT block v1.0 capture completed\n- 20/20 frozen scheduled runs captured; five each B1-B4. All prompt hashes and evidence seals verified on H:, in schedule order. No replacement attempts.\n- Completion audit: 08 Logs/Generation 3 Session 2/{report}.md and .json; execution ledger: GPT block execution.jsonl.\n- Rubric scoring and independent second scoring remain pending. Single-case exploratory block; other recipients remain outstanding.\n'
for p in [logs/'Session record.md',logs/'Recipient and run register.md',root/'08 Logs/chronology.md']:
 with p.open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({k:v for k,v in result.items() if k!='runs_verified'}))
