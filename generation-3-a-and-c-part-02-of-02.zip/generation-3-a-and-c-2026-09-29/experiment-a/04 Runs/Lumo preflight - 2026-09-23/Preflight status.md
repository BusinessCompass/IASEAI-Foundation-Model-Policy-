
## 2026-09-23T09:15:28.0284992+02:00 — Lumo authenticated preflight
Signed in Lumo Business; visible model Lumo 2.0 Max. Memory page offers Turn on memory, indicating OFF. Personalization name and occupation fields are populated; other-info and behavior fields empty. Original populated values preserved in preflight evidence for restoration. Ghost chat enabled; UI says disappears when closed and never saved, but does not establish profile exclusion. No target prompt entered/submitted and no block frozen. Request operator authorization to temporarily clear the two populated profile fields, preserving values for restoration after block. Evidence copied and hashes verified in 04 Runs/Lumo preflight - 2026-09-23.


## 2026-09-23T09:17:27.4668321+02:00 — Authorized temporary Lumo personalization clearing
Operator authorized 'yes, clear temporariy'. Cleared name and occupation only, saved, navigated away and back, and verified both remain blank with Save disabled. All four personalization text fields now empty. Initial fill-empty actions did not persist; keyboard selection/deletion succeeded before Save. No test prompt submitted. Original name Ken and occupation Analyis and primers preserved in personalization-observed.txt. Restoration of those exact values after Lumo testing remains required and authorized as part of temporary change. Cleared-state evidence copied to H: with matching SHA256.

