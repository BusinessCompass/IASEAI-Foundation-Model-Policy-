from pathlib import Path
from datetime import datetime
import json,hashlib,shutil,sys
root=Path('H:/Travel Booking Experiment Generation 3');local=Path(__file__).parent
sys.path.insert(0,str(local.parent/'G3S2-browser-fix-v0.2'))
import evidence_guard as g
source=root/'00 Method/Session 2 Experiment A - GPT block v1.0'
fm=json.loads((source/'freeze-manifest.json').read_text())
for n,h in fm['files'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h
method=root/'00 Method/Session 2 Experiment A - Copilot block v1.0';method.mkdir(exist_ok=False)
runs=json.loads((source/'schedule.json').read_text())['runs']
for r in runs:r['attempt_id']=r['attempt_id'].replace('P01','P05')
(method/'schedule.json').write_text(json.dumps({'design':'Same frozen matched order as prior platforms; no new randomization.','runs':runs},indent=2),encoding='utf-8')
protocol='''# Experiment A — Copilot block v1.0

Prospective freeze before P05 first submission, following GPT/Grok/Mistral/Lumo and frozen Gemini inability outcome. Four conditions, five repetitions, 20 slots; unchanged GPT frozen task/intervention prompts, rubric, reference and order. Data folder Run 5 Co Pilot desktop. This is exploratory matched replication, not preregistration before all results.

Copilot consumer WEB interface at copilot.microsoft.com, existing Business Compass account. Folder name Run 5 Co Pilot desktop retained historically; this block is browser-based, not desktop. Smart mode selected: thinks deeply or quickly based on task; exact backend/version not exposed. Preserve Smart; differences from other platform modes are confounds. No Search mode, connector, attachment or project selected. Unseen tool access not inferred.

Fresh visibly empty Temporary chat each run; UI says not saved to history, reflected in memory or used for training, retained up to 30 days. Personalisation and memory and Microsoft usage data originally ON; both explicitly authorized temporarily OFF, verified after reopening settings. Restore BOTH ON after block or suspension. Operator approved displayed terms and setting changes before submission. Prior automation approval failure was caused by Codex usage limit; no Copilot action was executed then. User redeemed one Codex reset credit; resumed here after ordinary usage allowed. This is not a target-platform technical attempt.

Scope amendment 02 expands testing to all seven original reserves after the Gemini outcome. Copilot is P05 first reserve; preserve all core outcomes including Gemini's one inability response and 19 unsubmitted slots. All reserves remain intended regardless of outcomes. Stop and preserve unexplained service failure, then continue roster under amendment; do not label it a reasoning failure or silently replace it.

Submit only exact corresponding SUBMIT prompt; withhold policy, BIGL, rubric, reference, labels and previous responses. Verify source SHA256 and normalized composer before exclusive send-intent and one send. Verify post-submission raw user text, allowing whitespace and rendered leading Markdown list markers only. Preserve source bytes and rendered text. Never blindly retry uncertain send.

Capture full response, submitted text, visible work/tool summaries, conversation-only DOM/text, viewport screenshot, timestamps and completion controls. Do not request hidden reasoning. Completion requires response action controls with no active generation. Seal/hash-verify each H: copy before resetting. Stop on settings/model/source changes or uncertain transmission. No corrections or regenerations for poor answers. At most one separately logged A02 replacement per technical failure after cause resolved; stop if replacement fails. Rate limits may require a recorded pause.

Apply unchanged rubric; decision, fare arithmetic, interpretation, assurance and adherence separate. No composite or inferential superiority claim. Lead unblinded. R01 of each condition preselected for separate second review, lead scores withheld, treatment unblinded; preserve disagreements. Report first attempts/recoveries, word counts and observed timings including overhead. One feasible case is insufficient for general reliability or infeasible-case claims. Original core plus all seven reserves under post-result Scope amendment 02; no erasure of Gemini or selective omission of reserve outcomes.
'''
(method/'Protocol.md').write_text(protocol,encoding='utf-8')
pre=local.parent/'Copilot-preflight'
for n in ['memory-original.txt','memory-disabled-verified.txt','temporary-chat.txt','mode-options.txt']:shutil.copy2(pre/n,method/n)
for r in runs:
 p=root/'02 Primers/Session 2 Experiment A - GPT block v1.0'/r['prompt_file']
 g.prepare(local,r['attempt_id'],r['condition'],p.read_text(encoding='utf-8'),r['prompt_sha256'])
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in method.iterdir() if p.is_file()}
files.update({n:h for n,h in fm['files'].items() if n.startswith(('02 Primers','05 Analysis'))})
at=datetime.now().astimezone().isoformat()
(method/'freeze-manifest.json').write_text(json.dumps({'at':at,'files':files},indent=2),encoding='utf-8')
entry=f'\n\n## {at} — Copilot P05 frozen before first submission\n20 slots, unchanged prompts/rubric/reference/order. Copilot WEB Smart; Temporary chats; Personalisation and memory OFF, Microsoft usage data OFF with approval. Both originally ON and must be restored. Scope amendment 02 applies; historical folder Run 5 Co Pilot desktop retained; actual interface browser. Prior Codex usage block was not a target attempt. Policy/BIGL withheld. Freeze: {method}. No target submission yet.\n'
for n in ['08 Logs/Generation 3 Session 2/Session record.md','08 Logs/Generation 3 Session 2/Recipient and run register.md','08 Logs/chronology.md']:
 with (root/n).open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({'prepared':20,'freeze':str(method)}))

