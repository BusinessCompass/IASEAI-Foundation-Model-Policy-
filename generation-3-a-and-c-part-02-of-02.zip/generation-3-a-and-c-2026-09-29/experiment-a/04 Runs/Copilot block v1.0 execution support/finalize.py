from pathlib import Path
from datetime import datetime
import sys,json,hashlib,shutil,re
root=Path('H:/Travel Booking Experiment Generation 3');local=Path(__file__).parent
run=json.loads((root/'00 Method/Session 2 Experiment A - Copilot block v1.0/schedule.json').read_text())['runs'][int(sys.argv[1])]
p=local/run['attempt_id'];done=json.loads((p/'completion.json').read_text())
assert done['request_verified'] and done['completion_controls']
assert hashlib.sha256((p/'request.txt').read_bytes()).hexdigest()==run['prompt_sha256']
norm=lambda s:' '.join(s.split())
req=(p/'request.txt').read_text(encoding='utf-8');sub=(p/'submitted-raw.txt').read_text(encoding='utf-8')
assert norm(req)==norm(sub) or norm(re.sub(r'^(?:- |\d+\. )','',req,flags=re.M))==norm(sub)
for n in ['response.txt','transcript.txt','transcript-dom.txt','screenshot.jpg','send-intent.json']:assert (p/n).stat().st_size>0
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.is_file()}
with (p/'sealed.json').open('x',encoding='utf-8') as f:json.dump({'at':datetime.now().astimezone().isoformat(),'files':hashes},f,indent=2)
dest=root/'01 Data/Run 5 Co Pilot desktop'/run['attempt_id'];shutil.copytree(p,dest)
for n,h in hashes.items():assert hashlib.sha256((dest/n).read_bytes()).hexdigest()==h
entry={'at':datetime.now().astimezone().isoformat(),'order':run['order'],'id':run['attempt_id'],'status':'captured_hash_verified','path':str(dest)}
with (root/'08 Logs/Generation 3 Session 2/Copilot block execution.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(entry)+'\n')
print(json.dumps(entry))



