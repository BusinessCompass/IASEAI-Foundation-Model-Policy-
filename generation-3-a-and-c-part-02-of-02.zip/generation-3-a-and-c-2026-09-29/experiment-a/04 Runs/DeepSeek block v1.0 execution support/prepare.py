from pathlib import Path
from datetime import datetime
import json,hashlib,sys,shutil
root=Path('H:/Travel Booking Experiment Generation 3');local=Path(__file__).parent
sys.path.insert(0,str(local.parent/'G3S2-browser-fix-v0.2'))
import evidence_guard as g
source=root/'00 Method/Session 2 Experiment A - GPT block v1.0'
fm=json.loads((source/'freeze-manifest.json').read_text(encoding='utf-8'))
for n,h in fm['files'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h
method=root/'00 Method/Session 2 Experiment A - DeepSeek block v1.0';method.mkdir(exist_ok=False)
runs=json.loads((source/'schedule.json').read_text(encoding='utf-8'))['runs']
for r in runs:r['attempt_id']=r['attempt_id'].replace('P01','P08')
(method/'schedule.json').write_text(json.dumps({'design':'Unchanged matched order; no new randomization.','runs':runs},indent=2),encoding='utf-8')
protocol='''# Experiment A — DeepSeek P08 prospective block freeze

Consumer web chat at https://chat.deepseek.com/, signed in. Fresh visibly empty New chat each trial, outside previous chats. Deep thinking OFF (original OFF), Smart Search OFF (original ON), Help improve the model for everyone OFF (original ON, operator-authorized and verified after leaving/reopening Data settings). Restore training and Smart Search ON after tests. No explicit model version exposed in inspected UI; record backend as unverified. No memory/custom-instruction control found in inspected General/Profile/Data panels; do not infer hidden isolation. No attachments or previous chats supplied.

Twenty slots: four conditions, five repetitions, unchanged GPT frozen prompts, reference, rubric and matched order. Policy and BIGL withheld; send only exact SUBMIT text, no labels/answers/assessment. Prospective platform freeze after prior results, not original preregistration. Scope amendment 03 makes this the final platform; do not start Qwen/Poe/Kimi/Chat ZAI. Earlier Gemini/OxAlpha failures remain preserved. Codex usage interruption was not a DeepSeek target attempt.

Verify source hash and composer before exclusive send-intent and one send. Preserve exact submitted text, full response and visible work/tool summaries, conversation-only DOM/text, screenshot and completion evidence. Seal/hash-verify H: copy before New chat. Never blindly resend or regenerate a poor answer. Stop and preserve unexplained service failure, source/model change or uncertain transmission. Separately recorded technical replacement only within existing retry limit after cause resolved. No hidden reasoning or tool execution inferred from text claims.

Unchanged six dimensions and separate decision, arithmetic, interpretation, assurance and adherence; no composite. Lead unblinded. Fixed R01 in each condition for second review, lead scores withheld, treatment visible, disagreements preserved. Report observed timing as including UI/capture overhead. One feasible synthetic case cannot support general reliability/superiority. Finish collection and evidence/assessment work within revised scope.
'''
(method/'Protocol.md').write_text(protocol,encoding='utf-8')
for n in ['Preflight status.md','training-original.txt','training-disabled-verified.txt','modes-preflight.json']:shutil.copy2(local/n,method/n)
for r in runs:
 p=root/'02 Primers/Session 2 Experiment A - GPT block v1.0'/r['prompt_file']
 g.prepare(local,r['attempt_id'],r['condition'],p.read_text(encoding='utf-8'),r['prompt_sha256'])
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in method.iterdir() if p.is_file()}
files.update({n:h for n,h in fm['files'].items() if n.startswith(('02 Primers','05 Analysis'))})
at=datetime.now().astimezone().isoformat()
(method/'freeze-manifest.json').write_text(json.dumps({'at':at,'files':files},indent=2),encoding='utf-8')
entry=f'\n\n## {at} — DeepSeek P08 frozen before first submission\n20 unchanged matched slots. Training OFF (authorized), Smart Search OFF, Deep thinking OFF. Training/Search originally ON and to restore after tests. Fresh empty New chat per trial; backend and hidden isolation unverified. Policy/BIGL withheld. Final platform under scope amendment 03. Freeze: {method}.\n'
for n in ['08 Logs/Generation 3 Session 2/Session record.md','08 Logs/Generation 3 Session 2/Recipient and run register.md','08 Logs/chronology.md']:
 with (root/n).open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({'prepared':20,'freeze':str(method)}))
