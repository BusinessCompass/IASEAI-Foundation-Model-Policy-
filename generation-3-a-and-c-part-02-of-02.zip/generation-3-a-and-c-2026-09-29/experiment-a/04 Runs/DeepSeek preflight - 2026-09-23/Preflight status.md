# DeepSeek P08 — preflight status

Operator authorized turning off "Help improve the model for everyone" for testing, with restoration afterwards. Original state ON. It was set OFF and verified after navigating away from Data settings and back. The initial automation command reported that its checked-state assertion had failed; subsequent UI observations showed the switch OFF, including after returning to Data. No repeated toggle was applied.

Smart Search originally ON; disabled for the closed-data experiment and verified aria-pressed=false. Deep thinking originally OFF and retained OFF. Preserve these settings across the block; record exact backend as unavailable until explicitly exposed. Restore original training ON and Smart Search ON after testing; Deep thinking remains OFF. No other setting changed.

Signed in, fresh empty chat at https://chat.deepseek.com/. General/Profile/Data settings inspected; no memory/custom-instruction control found in those panels. This does not establish absence of unseen personalization. No DeepSeek target prompt submitted yet. Scope amendment 03 makes DeepSeek the final target platform; remaining reserves are not to be started.

Evidence files: training-original.txt, training-disabled.txt, training-disabled-verified.txt, modes-preflight.json. These record UI state only; they do not independently validate the provider's data handling.
