# Copilot browser engineering pilot

16 September 2026. Two live submissions, separate normal chats, Smart mode. This is infrastructure testing, not Generation 3 primer-performance evidence. Neither original primer condition was used. Execution used Codex browser automation with supported Playwright locators and local evidence files; no standalone unattended Playwright runner has yet been built.

## Results

- Run 001: submitted a three-line echo/capture prompt once. Copilot returned all expected lines. Direct rendered-text capture matched exactly.
- Capture defect: clicking Copy message displayed Copied, but the browser clipboard returned empty text. The empty file is preserved as 001-response.txt; the verified answer is 001-response-dom.txt. Do not use clipboard success notifications as proof of capture. An initial transient checkpoint called the empty file captured; this was corrected to verified only after exact DOM capture. Production code must validate before writing a success status.
- Reload recovery: the first conversation recovered with identical response text and one user message. A persisted verified checkpoint was read and prevented a second submission. This was a simple guard demonstration, not concurrent-worker or crash-window validation.
- Run 002: submitted one synthetic four-pair travel problem. A deliberate reload occurred after the generating indicator had been observed. The completed response was recovered from the same conversation URL with one user message; it was not resent. Generation may have completed before reload; this does not prove recovery from an interrupted server-side generation.
- The second submitted message matched its saved request exactly. All four table rows, headers, decision and final marker were captured. Copilot selected O1 + R1 at EUR 200, the only valid pair. This correct answer is an engineering fixture result only.
- Screenshots, accessibility snapshots, exact requests, rendered responses, statuses and conversation URLs are preserved. Screenshots are viewport evidence and not a substitute for complete text capture.

## Limitations and next implementation requirements

Smart is adaptive; exact model version was not exposed. Fresh normal chats were used, but account-level memory was not verified or disabled. No claim of context isolation beyond separate chats is made. No API usage/token counts were available. No exact generation latency was measured.

Not yet validated: genuine network outage, deliberate response cancellation, site rate limit, long/virtualised answers, multiple response blocks, attachments, actual process crash/restart, concurrent duplicate prevention, and ambiguity between click and receipt acknowledgement. A standalone unattended runner does not yet exist. Its durable event journal must record intent before submission and reconcile the conversation after uncertain outcomes rather than retry blindly. Pending/unknown must never be relabelled successful from a timeout alone.

The initial navigation timed out while the tab actually opened. Recovery inspected the existing tab instead of opening a duplicate. This is another reason to reconcile observable state after errors.

Readiness: basic signed-in browser submission, rendered-text capture, table capture and page-reload recovery demonstrated. Not ready for the proposed 360-run batch. Next step is a durable runner with fail-closed completion checks, immutable events and additional fault-injection tests, using DOM capture rather than clipboard-only extraction.
