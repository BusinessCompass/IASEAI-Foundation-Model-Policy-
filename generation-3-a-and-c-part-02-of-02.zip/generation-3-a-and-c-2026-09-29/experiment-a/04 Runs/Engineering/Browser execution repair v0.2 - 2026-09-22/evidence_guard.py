"""Append-only evidence guard. Browser interaction stays in cua_repl.
A failed/missing checkpoint never authorises automatic re-submission.
"""
import hashlib,json,re
from pathlib import Path
from datetime import datetime,timezone

def stamp(): return datetime.now(timezone.utc).isoformat()
def digest(data): return hashlib.sha256(data).hexdigest()
def normal(text): return ' '.join(text.split())
def write_json(path,value):
 with Path(path).open('x',encoding='utf-8') as f: json.dump(value,f,indent=2)
def read_json(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def verify(run):
 run=Path(run); m=read_json(run/'prepared.json')
 if digest((run/'request.txt').read_bytes()) != m['request_sha256']: raise ValueError('REQUEST_HASH_MISMATCH')
 return m

def prepare(root,attempt_id,condition,request,source_hash):
 if not re.fullmatch(r'[A-Za-z0-9_-]+',attempt_id): raise ValueError('INVALID_ID')
 data=request.encode('utf-8')
 if digest(data)!=source_hash: raise ValueError('SOURCE_HASH_MISMATCH')
 run=Path(root)/attempt_id
 run.mkdir(parents=False,exist_ok=False) # atomic duplicate guard; never reuse ID
 with (run/'request.txt').open('xb') as f:f.write(data)
 write_json(run/'prepared.json',dict(attempt_id=attempt_id,condition=condition,request_sha256=source_hash,prepared_at=stamp()))
 return run

def arm(run,composer_text,empty_chat,unpersonalized,model,effort):
 run=Path(run);verify(run)
 if (run/'send-intent.json').exists(): raise ValueError('SEND_ALREADY_ATTEMPTED_OR_UNCERTAIN')
 if not empty_chat or not unpersonalized: raise ValueError('SESSION_NOT_ISOLATED')
 if normal(composer_text)!=normal((run/'request.txt').read_text(encoding='utf-8')): raise ValueError('COMPOSER_MISMATCH')
 write_json(run/'send-intent.json',dict(at=stamp(),model=model,effort=effort,comparison='whitespace-normalised; source bytes retained',empty_chat=True,unpersonalized=True))
 # Next action may click Send once. A crash here needs inspection, not a resend.

def capture(run,submitted_text,transcript,dom,screenshot,completion_visible,work_panels_reviewed):
 run=Path(run);verify(run)
 if not (run/'send-intent.json').exists(): raise ValueError('NOT_ARMED')
 if (run/'captured.json').exists(): raise ValueError('ALREADY_CAPTURED')
 # Preserve raw capture even on mismatch. Never use clipboard or guessed Show-more slicing.
 payloads={'submitted-visible.txt':submitted_text.encode(),'transcript.txt':transcript.encode(),'transcript-dom.txt':dom.encode(),'screenshot.png':screenshot}
 for name,data in payloads.items():
  with (run/name).open('xb') as f:f.write(data)
 problems=[]
 if normal(submitted_text)!=normal((run/'request.txt').read_text(encoding='utf-8')):problems.append('SUBMITTED_REQUEST_MISMATCH')
 if not completion_visible:problems.append('COMPLETION_NOT_VERIFIED')
 if not work_panels_reviewed:problems.append('VISIBLE_WORK_NOT_REVIEWED')
 if not transcript.strip() or not dom.strip() or not screenshot:problems.append('EMPTY_EVIDENCE')
 write_json(run/'captured.json',dict(at=stamp(),status='quarantined' if problems else 'captured',problems=problems))
 if problems:raise ValueError(','.join(problems))

def seal(run):
 run=Path(run);verify(run)
 if read_json(run/'captured.json')['status']!='captured':raise ValueError('QUARANTINED')
 for name in ['submitted-visible.txt','transcript.txt','transcript-dom.txt','screenshot.png','send-intent.json']:
  if not (run/name).is_file():raise ValueError('MISSING_EVIDENCE')
 hashes={p.name:digest(p.read_bytes()) for p in run.iterdir() if p.is_file()}
 write_json(run/'sealed.json',dict(at=stamp(),files=hashes))

def verify_seal(run):
 run=Path(run);m=read_json(run/'sealed.json')
 if not all((run/n).is_file() and digest((run/n).read_bytes())==h for n,h in m['files'].items()):raise ValueError('EVIDENCE_HASH_MISMATCH')
 return True
