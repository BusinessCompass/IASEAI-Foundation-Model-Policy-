# Browser execution repair v0.2

Status: corrected supervised procedure, eight guard tests and one live infrastructure capture passed. Not an unattended batch runner. Original experimental evidence and prompts remain unchanged.

## Defects and dispositions

D01 Stale clipboard: the earlier three-line check passed but later copy operations returned old text. Browser clipboard defect itself is not repaired. Removed clipboard from the authoritative path: directly capture the displayed submitted message, full main transcript, DOM representation and screenshot. No reliance on Copy notification or string slicing at Show more. Retain expanded visible work where present. Full transcript is authoritative; any extracted answer is a derived artifact.

D02 Wrong condition and reused bindings: intended B2 displayed B4. Exact runtime cause remains unproven. Remove the previous submitPilot/savePilot helpers from the operating procedure. Use explicit literal attempt paths and direct UI actions, with a file-based guard. Source hash, composer text, fresh-session status and displayed submitted text are checked. Preserve post-send mismatches as quarantined evidence. Do not count them or silently replace them.

D03 Overwrite/retry ambiguity: prepared.json and request.txt are exclusively created in a unique directory. send-intent.json is written once before clicking Send. Existing intent means submitted-or-uncertain: inspect the page, never automatically click again. Evidence captures and seals use exclusive creation. Verify copied evidence hashes before clearing/resetting the page.

D04 Missing work/chronology: inspect response for expandable work summaries, expand and capture visible records before sealing. A final transcript is not a timestamped streaming record or proof of internal processing. No claim of solving model-generated chronology shortcomings; B3/B4 adherence observations remain for assessment.

## Supervised operating sequence

1. Create a fresh temporary chat through visible navigation; do not assume reload creates one. Inspect empty conversation, Unpersonalized and visible model/effort. During repair, reload retained a saved PDCA conversation URL, so explicit navigation to a fresh temporary chat was required. Cause of the saved state is unknown; no experimental continuity is inferred.
2. Use evidence_guard.prepare with literal ID/condition and the expected hash from the frozen source manifest. Every browser call must reference the prepared request for that exact ID, not shared mutable nextPrompt/runDir bindings.
3. Fill the composer; read its actual text. Run arm with the observed text and inspected session properties. Whitespace-only normalisation is allowed for browser rendering; exact source bytes remain retained.
4. Click Send once using a direct browser tool action. Inspect the displayed user message immediately. After uncertainty or a failed command, inspect; never automatically resend. The guard is a process gate and cannot prevent someone bypassing it with a manual click.
5. Wait for response controls and absence of Stop answering. Capture exact displayed user text, entire main transcript, DOM representation and screenshot using browser APIs. Inspect all visible work panels. Verify target response boundaries and table completeness from the DOM; do not trust clipboard contents or inferred hidden work.
6. Run capture and seal. Mismatch/incompleteness is retained but quarantined. Verify the seal, copy the evidence bundle to its H recipient folder, and verify all hashes before navigating away.
7. On recovery, verify prepared/hash/checkpoints. Existing send intent with no completed capture needs page inspection or an explicit unresolved-attempt record. A new attempt gets a new ID. Timing means observed wall time, not clean model latency.

## Validation

Eight local tests passed: duplicate ID; wrong source hash; stale composer; interruption after arming; post-submit mismatch quarantining; incomplete response; unreviewed work; sealed evidence tampering. Test fixture bytes are synthetic and not screenshots.

Live FIX02-LIVE-T01: fresh unpersonalized temporary chat, Medium effort; inherited model previously observed as GPT-5.6 Sol. Submitted text exact-match verified; full table with FIX02-A/17 and FIX02-B/29 plus END-FIX02 captured directly from page. Completion actions visible; no expandable work panel appeared. Capture sealed and verified; duplicate arming rejected. No clipboard was read or used. One live infrastructure request, no new travel-condition runs.

Limits: long-response, expanded-work and interruption recovery are not all live-retested by this short table case. They remain required supervised checks. Independent scientific scoring/reference review remains outstanding. These changes repair experimental execution controls, not target policy effectiveness.
