import tempfile,unittest
from pathlib import Path
import evidence_guard as g
class GuardTests(unittest.TestCase):
 def setUp(self):self.t=tempfile.TemporaryDirectory();self.root=Path(self.t.name)
 def tearDown(self):self.t.cleanup()
 def prep(self):return g.prepare(self.root,'TEST-B2-T01','B2','PDCA request',g.digest(b'PDCA request'))
 def armed(self):
  r=self.prep();g.arm(r,'PDCA request',True,True,'visible model','Medium');return r
 def test_duplicate_id(self):
  self.prep()
  with self.assertRaises(FileExistsError):self.prep()
 def test_wrong_source_hash(self):
  with self.assertRaisesRegex(ValueError,'SOURCE_HASH'):g.prepare(self.root,'X','B2','wrong','0')
 def test_wrong_composer_prevents_send(self):
  r=self.prep()
  with self.assertRaisesRegex(ValueError,'COMPOSER'):g.arm(r,'B4 stale request',True,True,'m','e')
  self.assertFalse((r/'send-intent.json').exists())
 def test_crash_after_arm_cannot_resend(self):
  r=self.armed()
  with self.assertRaisesRegex(ValueError,'SEND_ALREADY'):g.arm(r,'PDCA request',True,True,'m','e')
 def test_post_submission_mismatch_quarantined(self):
  r=self.armed()
  with self.assertRaisesRegex(ValueError,'SUBMITTED_REQUEST'):g.capture(r,'B4','full transcript','dom',b'png',True,True)
  self.assertTrue((r/'transcript.txt').exists())
  with self.assertRaisesRegex(ValueError,'QUARANTINED'):g.seal(r)
 def test_incomplete_capture_quarantined(self):
  r=self.armed()
  with self.assertRaisesRegex(ValueError,'COMPLETION'):g.capture(r,'PDCA request','t','d',b'p',False,True)
 def test_unreviewed_work_quarantined(self):
  r=self.armed()
  with self.assertRaisesRegex(ValueError,'VISIBLE_WORK'):g.capture(r,'PDCA request','t','d',b'p',True,False)
 def test_success_seal_detects_tampering(self):
  r=self.armed();g.capture(r,'PDCA request','t','d',b'p',True,True);g.seal(r);self.assertTrue(g.verify_seal(r))
  (r/'transcript.txt').write_text('changed')
  with self.assertRaisesRegex(ValueError,'HASH'):g.verify_seal(r)
if __name__=='__main__':unittest.main(verbosity=2)
