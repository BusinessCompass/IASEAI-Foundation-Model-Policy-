from pathlib import Path
from datetime import datetime
import hashlib,json,shutil,collections
root=Path('H:/Travel Booking Experiment Generation 3');local=Path(__file__).parent
method=root/'00 Method/Session 2 Experiment A - Mistral block v1.0'
runs=json.loads((method/'schedule.json').read_text())['runs']
log=root/'08 Logs/Generation 3 Session 2'
ledger=[json.loads(s) for s in (log/'Mistral block execution.jsonl').read_text().splitlines()]
assert [x['id'] for x in ledger]==[x['attempt_id'] for x in runs[:10]]
verified=0
for r in runs[:10]:
 p=root/'01 Data/Run 3 Vibe'/r['attempt_id']
 for n,h in json.loads((p/'sealed.json').read_text())['files'].items():
  assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h;verified+=1
for n,h in json.loads((method/'freeze-manifest.json').read_text())['files'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h
r=runs[10];p=local/r['attempt_id'];status=json.loads((p/'technical-status.json').read_text())
assert status['assistant_message_count']==0 and status['request_verified']
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.is_file()}
at=datetime.now().astimezone().isoformat()
with (p/'sealed.json').open('x',encoding='utf-8') as f:json.dump({'at':at,'status':'technical_platform_limit_not_evaluable','files':hashes},f,indent=2)
dest=root/'01 Data/Run 3 Vibe'/r['attempt_id'];shutil.copytree(p,dest)
for n,h in hashes.items():assert hashlib.sha256((dest/n).read_bytes()).hexdigest()==h
entry={'at':at,'order':11,'id':r['attempt_id'],'status':'platform_message_limit_no_response','path':str(dest),'evaluable':False}
with (log/'Mistral block execution.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(entry)+'\n')
counts=dict(collections.Counter(r['condition'] for r in runs[:10]))
data={'at':at,'status':'interrupted_platform_message_limit','completed':10,'completed_per_condition':counts,'complete_response_hashes_verified':verified,'technical_attempt_hashes_verified':len(hashes),'blocked_slot':11,'blocked_id':r['attempt_id'],'unstarted_slots':list(range(12,21)),'notice_reset':'in 3 hours (UI statement; no guaranteed reset time)','replacement_attempts':0,'next_action':'After limit clears inspect interrupted chat before any resubmission. If still no response, prepare at most one separately logged A02 for slot 11 under frozen replacement rule; retain A01. Then continue slots 12-20 in original order.'}
with (log/'Mistral block checkpoint - 2026-09-22.json').open('x',encoding='utf-8') as f:json.dump(data,f,indent=2)
md=f'''# Mistral block checkpoint

Recorded {at}. Ten completed responses saved and all {verified} sealed evidence hashes verified on H:. Counts: {counts}. Slot 11 ({r['attempt_id']}) was submitted once with exact request verified, but Mistral displayed “Messages limit reached”, reset “in 3 hours”. No assistant message exists. Technical limit evidence copied and all {len(hashes)} hashes verified. This is not a model reasoning failure. Slots 12–20 remain unstarted. No replacement attempted.

Preliminary decision inspection: nine optimal O1/R1 at EUR 460; B1 R03 chose invalid O2/R1 at EUR 330, falsely claiming 08:15 is before 07:30. Several other responses reject eligible O3. These are observations, not completed rubric scores. Formal scoring and second review remain pending. Do not infer reliability or superiority from this partial block.

Resume: inspect interrupted chat after limit clears. If no response exists, record A01 as technical non-evaluable and prepare at most one separately identified A02 replacement for slot 11; do not overwrite or rerun blindly. Continue original slots 12–20 after capturing and verifying that replacement. Recheck Fast/incognito and personalization controls after the break. No automatic restart scheduled.

Capture notes: response.txt preserves rendered assistant container including UI timestamp and, in B4 R02, a feedback prompt. Exclude UI text transparently in derived word counts; keep raw files untouched. Incognito reload was observed to create empty chat before each trial. Composer cards expanded and matched before each send.
'''
with (log/'Mistral block checkpoint - 2026-09-22.md').open('x',encoding='utf-8') as f:f.write(md)
support=root/'04 Runs/Mistral block v1.0 execution support';support.mkdir(exist_ok=False)
for f in local.iterdir():
 if f.is_file():shutil.copy2(f,support/f.name)
for n in ['Session record.md','Recipient and run register.md']:
 with (log/n).open('a',encoding='utf-8') as f:f.write('\n\n'+md)
with (root/'08 Logs/chronology.md').open('a',encoding='utf-8') as f:f.write('\n\n'+md)
print(json.dumps(data))
