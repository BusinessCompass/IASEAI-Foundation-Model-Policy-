from pathlib import Path
from datetime import datetime
import json,hashlib,shutil,sys
root=Path('H:/Travel Booking Experiment Generation 3'); local=Path(__file__).parent
sys.path.insert(0,str(local.parent/'G3S2-browser-fix-v0.2'))
import evidence_guard as g
source=root/'00 Method/Session 2 Experiment A - GPT block v1.0'
fm=json.loads((source/'freeze-manifest.json').read_text())
for n,h in fm['files'].items(): assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h
method=root/'00 Method/Session 2 Experiment A - Mistral block v1.0'; method.mkdir(exist_ok=False)
runs=json.loads((source/'schedule.json').read_text())['runs']
for r in runs: r['attempt_id']=r['attempt_id'].replace('P01','P03')
(method/'schedule.json').write_text(json.dumps({'design':'Same frozen order as GPT and Grok for matched exploratory replication; no new independent randomization.','runs':runs},indent=2),encoding='utf-8')
protocol='''# Experiment A — Mistral target block v1.0

Prospective freeze for P03, case T01: four conditions, five repetitions, 20 slots. Same frozen GPT prompts, rubric, reference and schedule order. Freeze follows GPT and Grok results; not a preregistration before all results. Existing data folder Run 3 Vibe maps to Mistral's observed Vibe web service at chat.mistral.ai.

Target Chat / Fast. Exact backend model unavailable. Fresh visibly empty Incognito chat per attempt. Memories observed OFF; Knowledge and Localisation switched OFF with explicit operator approval and verified. Saved material preserved. Incognito banner states temporary chats are not saved or used for training; this is not proof of all hidden platform isolation. No project, agent, library, attachment or extra context is selected. Pre-existing account chats are not opened or submitted. Custom instruction isolation is not independently exposed by this UI; retain that limitation.

Only corresponding exact frozen SUBMIT prompt goes to target: withhold policy, BIGL, rubric, reference, condition labels, prior responses and scores. Verify empty Incognito and Fast before each submission. Source SHA256, composer comparison and exclusive send-intent precede one send. Post-submit compare whitespace, with rendered leading Markdown list markers optionally removed. No semantic edits. Preserve raw source and rendered user text. Any mismatch or uncertain send stops execution; never blindly resend.

Capture full rendered response, submitted text, transcript, DOM, viewport screenshot, timestamps and completion controls. Completion requires response action controls and no active generation/Stop control. Inspect available work summaries without asking for hidden reasoning. Seal and verify H: hashes before resetting. No corrective prompts or regeneration for poor results. Substantive violations remain findings. Technical failures separate; at most one A02 replacement after cause resolved, otherwise stop. Stop on settings/model/source change.

Unchanged six-dimension rubric; decision and substantive breaches separate; no composite. Lead review unblinded. R01 of each condition preselected for second review by another platform, with lead scores withheld. Preserve disagreements. Report scheduled/evaluable counts, attempts, observed timings including overhead, and word counts. Five selected platforms are GPT, Grok, Mistral, Lumo, Gemini; other seven reserved. No result-dependent stopping or substitution. One feasible case cannot establish general reliability or superiority.
'''
(method/'Protocol.md').write_text(protocol,encoding='utf-8')
pre=root/'04 Runs/Mistral preflight - 2026-09-22'
for name in ['privacy-disabled.txt','privacy-disabled.jpg','Acceptance and access update.md']: shutil.copy2(pre/name,method/name)
for r in runs:
 p=root/'02 Primers/Session 2 Experiment A - GPT block v1.0'/r['prompt_file']
 g.prepare(local,r['attempt_id'],r['condition'],p.read_text(encoding='utf-8'),r['prompt_sha256'])
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in method.iterdir() if p.is_file()}
files.update({n:h for n,h in fm['files'].items() if n.startswith(('02 Primers','05 Analysis'))})
at=datetime.now().astimezone().isoformat()
(method/'freeze-manifest.json').write_text(json.dumps({'at':at,'files':files},indent=2),encoding='utf-8')
entry=f'\n\n## {at} — Mistral P03 block frozen before first submission\n20 slots; Chat Fast, exact backend unavailable; fresh Incognito each attempt. Memories, Knowledge, Localisation OFF verified. Same frozen prompts, rubric and matched order. Policy/BIGL withheld. Data mapping Run 3 Vibe. Freeze: {method}. UI does not independently expose all custom-context isolation; limitation retained.\n'
for n in ['08 Logs/Generation 3 Session 2/Session record.md','08 Logs/Generation 3 Session 2/Recipient and run register.md','08 Logs/chronology.md']:
 with (root/n).open('a',encoding='utf-8') as f:f.write(entry)
print(json.dumps({'prepared':len(runs),'freeze':str(method)}))
