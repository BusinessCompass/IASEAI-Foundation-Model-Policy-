# Session 2 Experiment A pilot pack v0.1

Status: reviewable engineering draft, not a frozen formal experiment. No target submissions made by preparation of this pack.

## Operator procedure

Use only the appropriate `B1/B2/B3/B4 ... - SUBMIT.txt` content in a fresh target session. Each is self-contained. Do not attach the policy, BIGL tables, source paper, this README, reference answer, scoring material or other condition prompts. Do not tell the target the expected answer, hypotheses or condition label. B1 contains exactly the common task and no governance intervention; allow spontaneously generated structure.

For the engineering pilot, use the same visible model/mode and available resources across the four conditions. Record platform, actual visible model label, memory/personalisation settings and any settings that cannot be verified. Do not infer the underlying model from a platform name. The first platform remains to be selected. Use a recorded order before starting; proposed first engineering order is B3, B1, B4, B2. This one order is not a balanced formal schedule.

Submit one request and capture the first completed response. No corrective follow-up or regeneration to improve an answer. If the target asks a question, retain it as an incomplete response; do not supply improvised facts. Record technical failures separately. A retry is a new attempt and never replaces evidence. Record browser submission and completion times externally, alongside screenshots and complete visible text. Verify that capture is complete. Do not infer a contemporaneous chronology merely from a final response claiming that actions happened in sequence.

Save evidence beneath the matching existing `01 Data/Run N recipient` folder in a new per-attempt subfolder, using IDs from the Session 2 run register with an ENG prefix. Keep scoring outside recipient submissions under `05 Analysis/Session 2 Experiment A - DO NOT SUBMIT/Pilot v0.1`. Retain hashes of exact submitted text and response files. No recipient folders have been populated by pack preparation.

## Task provenance and scope

The Dignum and Dignum paper Agentifying Agentic AI, local PDF in 00 Method, motivates attendance-preserving travel selection (page 1) and avoiding circuitous routes (page 4). It does not provide this numerical dataset. Dates, options, fares, direct-only rule, timing margins, budget, tie rule and closed-data recommendation scope in this pilot are new synthetic experimental specifications authored by Codex. They are not quotations, recovered historical data or facts attributed to the paper. The earlier primer-construction prompt is provenance for Session 1, not an instruction governing this new execution draft.

This pilot tests a recommendation task, not real booking, external action, changing prices or demonstrated safety of high-impact deployment. All four treatments receive identical task facts and action limits. Test under stronger governance does not classify this synthetic activity as inherently BIGL 4.

## Treatment interpretation

B1: common task only. B2: PDCA with a concise check/correction account. B3: CIPDA, proportionate visible chronology, ROMER and governance review. B4: explicit sequential procedure with gates, option and combination coverage, controlled correction and completion/exception rules, ROMER and scorecard. The method's explicit BIGL 3 ROMER requirement applies.

Governance changes include prompt length, prescribed checks, recording and procedural detail. These are part of the intervention package; this design cannot isolate framework naming from verbosity or explicit algorithmic assistance. Completion is a single response in this pilot, so gates are model-instructed, not externally enforced. A later interactive workflow would be a separate protocol change. Independent assurance is performed after execution by a reviewer other than the target, not by asking the target to declare itself independent.

## Readiness

The draft common task is byte-identical in all four submissions. A deterministic check enumerates all 16 pairs; its answer and checks are withheld. Reference validation has been performed by the drafting assistant, not an independent reviewer. Independent reference review, rubric agreement, platform selection, browser capture recovery and intervention review remain before a formal freeze. Engineering responses are excluded from formal results.

One feasible case checks basic operation but cannot measure false acceptance on infeasible inputs or establish governance proportionality across consequence levels. Add separately validated feasible, infeasible and boundary cases before broad effectiveness claims. Do not interpret repetitions of this case as independent task samples.
